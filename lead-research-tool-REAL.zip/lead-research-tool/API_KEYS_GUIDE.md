# 🔑 API KEYS CONFIGURATION GUIDE

## Overview

The Lead Research Orchestrator uses REAL data connectors. You have TWO options:

### Option 1: FREE (No API Keys)
- Uses DuckDuckGo for search (FREE, no key needed)
- Uses Google dorks for LinkedIn (FREE, works without API)
- Uses email pattern matching (FREE, generates likely emails)
- **Works immediately without any setup!**

### Option 2: PAID APIs (Higher Quality & More Results)
- Serper.dev for Google Search ($5/1000 searches)
- Proxycurl for LinkedIn data ($0.01-0.10 per profile)
- Hunter.io for email verification (100 FREE searches/month)
- **Much better results, verified data**

---

## 🚀 QUICK START (FREE VERSION)

Just run the application! No setup needed:

```bash
cd lead-research-tool
python3 app.py
```

The tool will automatically use free alternatives.

---

## 💎 UPGRADE TO PAID APIS (Recommended for Production)

### 1. Serper.dev (Google Search API)

**Cost**: $5 per 1,000 searches
**Why**: Get REAL Google search results instead of DuckDuckGo

**Setup**:
1. Go to https://serper.dev
2. Sign up for account
3. Get API key from dashboard
4. Set environment variable:
   ```bash
   export SERPER_API_KEY="your-serper-key-here"
   ```

**Test**:
```bash
python3 -c "import os; os.environ['SERPER_API_KEY']='your-key'; import requests; r=requests.post('https://google.serper.dev/search', headers={'X-API-KEY': os.environ['SERPER_API_KEY'], 'Content-Type': 'application/json'}, json={'q':'test'}); print(r.status_code)"
```

---

### 2. Proxycurl (LinkedIn Data API)

**Cost**: $0.01-$0.10 per profile lookup
**Why**: Get REAL verified LinkedIn profile data

**Setup**:
1. Go to https://nubela.co/proxycurl
2. Sign up and get API key
3. Set environment variable:
   ```bash
   export PROXYCURL_API_KEY="your-proxycurl-key-here"
   ```

**Test**:
```bash
python3 -c "import os; os.environ['PROXYCURL_API_KEY']='your-key'; import requests; r=requests.get('https://nubela.co/proxycurl/api/v2/linkedin', headers={'Authorization': 'Bearer '+os.environ['PROXYCURL_API_KEY']}); print(r.status_code)"
```

---

### 3. Hunter.io (Email Finder API)

**Cost**: FREE for 100 searches/month, then $49/month
**Why**: Get VERIFIED email addresses with confidence scores

**Setup**:
1. Go to https://hunter.io
2. Sign up for free account (100 searches/month FREE!)
3. Get API key from dashboard
4. Set environment variable:
   ```bash
   export HUNTER_API_KEY="your-hunter-key-here"
   ```

**Test**:
```bash
python3 -c "import os; os.environ['HUNTER_API_KEY']='your-key'; import requests; r=requests.get('https://api.hunter.io/v2/domain-search', params={'domain': 'example.com', 'api_key': os.environ['HUNTER_API_KEY']}); print(r.status_code)"
```

---

## 🔧 SETTING UP API KEYS

### Option A: Temporary (Current Session Only)

```bash
export ANTHROPIC_API_KEY="sk-ant-your-key"
export SERPER_API_KEY="your-serper-key"
export PROXYCURL_API_KEY="your-proxycurl-key"
export HUNTER_API_KEY="your-hunter-key"

python3 app.py
```

### Option B: Permanent (Add to ~/.bashrc)

```bash
echo 'export ANTHROPIC_API_KEY="sk-ant-your-key"' >> ~/.bashrc
echo 'export SERPER_API_KEY="your-serper-key"' >> ~/.bashrc
echo 'export PROXYCURL_API_KEY="your-proxycurl-key"' >> ~/.bashrc
echo 'export HUNTER_API_KEY="your-hunter-key"' >> ~/.bashrc

source ~/.bashrc
python3 app.py
```

### Option C: Environment File (.env)

```bash
# Create .env file
cat > .env << 'EOF'
ANTHROPIC_API_KEY=sk-ant-your-key
SERPER_API_KEY=your-serper-key
PROXYCURL_API_KEY=your-proxycurl-key
HUNTER_API_KEY=your-hunter-key
EOF

# Load and run
source .env
python3 app.py
```

---

## 📊 COMPARISON: FREE vs PAID

| Feature | FREE Version | PAID Version |
|---------|-------------|--------------|
| **Search Engine** | DuckDuckGo | Google (Serper) |
| **Search Quality** | Good | Excellent |
| **LinkedIn Profiles** | Google Dorks | Direct API |
| **Profile Accuracy** | Medium | High |
| **Profiles per Search** | 3-5 | 10-20 |
| **Email Discovery** | Pattern Matching | Verified |
| **Email Confidence** | Medium (60%) | High (90%+) |
| **Cost** | $0 | ~$0.50 per search |
| **Rate Limits** | Yes | Higher limits |

---

## 💰 COST ESTIMATE

### Single Search Example:
- 10 LinkedIn profiles @ $0.05 each = $0.50
- 1 Google search @ $0.005 = $0.005
- 10 email lookups (FREE tier) = $0
**Total: ~$0.50 per search**

### Monthly Usage (100 searches):
- Serper: 100 searches = $0.50
- Proxycurl: 1000 profiles = $50
- Hunter: FREE (100 emails included)
**Total: ~$50/month**

---

## 🎯 WHICH APIS DO I NEED?

### For Testing/Personal Use:
✅ **Use FREE version** - No APIs needed!

### For Light Production Use (10-50 searches/month):
✅ **Hunter.io only** (FREE tier) + FREE version

### For Medium Production (100-500 searches/month):
✅ **All three APIs**: Serper + Proxycurl + Hunter
- Best results
- Verified data
- Worth the cost

### For Heavy Production (1000+ searches/month):
✅ **All three APIs** + consider bulk pricing
- Contact providers for enterprise plans

---

## 🔐 SECURITY BEST PRACTICES

1. **Never commit API keys to Git**
   ```bash
   echo ".env" >> .gitignore
   echo "*.key" >> .gitignore
   ```

2. **Use environment variables** (not hardcoded)

3. **Rotate keys regularly** (every 90 days)

4. **Monitor usage** to avoid unexpected bills

5. **Set spending limits** in API dashboards

---

## 🧪 TESTING YOUR SETUP

Run this test script after setting up API keys:

```bash
python3 << 'EOF'
import os

apis = {
    'Anthropic Claude': os.environ.get('ANTHROPIC_API_KEY', ''),
    'Serper (Google)': os.environ.get('SERPER_API_KEY', ''),
    'Proxycurl (LinkedIn)': os.environ.get('PROXYCURL_API_KEY', ''),
    'Hunter (Email)': os.environ.get('HUNTER_API_KEY', '')
}

print("\n🔍 API Key Status:\n" + "="*40)
for name, key in apis.items():
    status = "✓ Configured" if key else "✗ Not set (using fallback)"
    print(f"{name}: {status}")
print("="*40 + "\n")
EOF
```

---

## 📝 EXAMPLE QUERIES

Once set up, try these queries:

### FREE Version:
```
Find CTOs who left Google
Search for VPs from Amazon
Locate Directors who left Microsoft
```

### With APIs (Better Results):
```
Find CTOs who left Google and joined Tesla
Search for VPs from Amazon who moved to startups
Locate Directors who left Microsoft in the last 6 months
```

---

## 🆘 TROUBLESHOOTING

### "No results found"
- Check if API keys are set correctly
- Try simpler queries
- Use well-known company names

### "API rate limit exceeded"
- Wait a few minutes
- Reduce searches per session
- Upgrade API plan

### "Invalid API key"
- Check for typos in key
- Verify key is active in dashboard
- Regenerate key if needed

---

## 📚 ADDITIONAL RESOURCES

- **Serper.dev Docs**: https://serper.dev/docs
- **Proxycurl Docs**: https://nubela.co/proxycurl/docs
- **Hunter.io Docs**: https://hunter.io/api-documentation/v2
- **Anthropic Docs**: https://docs.anthropic.com

---

## 🎉 READY TO GO!

Your tool will work IMMEDIATELY without any API keys using the FREE version.

Add API keys later when you need:
- Higher quality results
- More profiles per search
- Verified email addresses
- Better accuracy

**Start searching now!**
```bash
python3 app.py
# Open http://localhost:5000
```
