#!/usr/bin/env python3
"""
Lead Research Orchestrator - OSINT Tool with REAL Data Connectors
Finds professionals who recently changed companies using actual web scraping and APIs
NO DEMO DATA - REAL RESULTS ONLY
"""

import os
import json
import re
import time
from datetime import datetime
from flask import Flask, render_template, request, jsonify, send_file
import pandas as pd
from urllib.parse import quote_plus, urlencode
import requests
from bs4 import BeautifulSoup
import anthropic
from typing import List, Dict, Optional
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

app = Flask(__name__)

# Configuration - Set these as environment variables
ANTHROPIC_API_KEY = os.environ.get('ANTHROPIC_API_KEY', '')
SERPER_API_KEY = os.environ.get('SERPER_API_KEY', '')  # https://serper.dev (Google Search)
PROXYCURL_API_KEY = os.environ.get('PROXYCURL_API_KEY', '')  # https://nubela.co/proxycurl
HUNTER_API_KEY = os.environ.get('HUNTER_API_KEY', '')  # https://hunter.io
OUTPUT_DIR = '/home/claude/lead-research-tool/outputs'
os.makedirs(OUTPUT_DIR, exist_ok=True)


class RealDataConnector:
    """Base connector for real data sources"""
    
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        })
        
    def search_with_retry(self, url, params=None, headers=None, max_retries=3):
        """Make HTTP request with retry logic"""
        for attempt in range(max_retries):
            try:
                response = self.session.get(url, params=params, headers=headers, timeout=15)
                response.raise_for_status()
                return response
            except Exception as e:
                logger.warning(f"Attempt {attempt + 1} failed for {url}: {e}")
                if attempt == max_retries - 1:
                    raise
                time.sleep(2 ** attempt)
        return None


class GoogleSearchConnector(RealDataConnector):
    """Real Google Search using Serper.dev API or DuckDuckGo fallback"""
    
    def __init__(self, api_key=None):
        super().__init__()
        self.api_key = api_key
        
    def search(self, query: str, num_results: int = 10) -> List[Dict]:
        """Search Google using available methods"""
        logger.info(f"Searching: {query}")
        
        if self.api_key:
            return self._search_with_serper(query, num_results)
        else:
            return self._search_with_duckduckgo(query, num_results)
    
    def _search_with_serper(self, query: str, num_results: int) -> List[Dict]:
        """Search using Serper.dev API (REAL Google results)"""
        try:
            url = "https://google.serper.dev/search"
            headers = {
                'X-API-KEY': self.api_key,
                'Content-Type': 'application/json'
            }
            payload = {
                'q': query,
                'num': num_results
            }
            
            response = requests.post(url, headers=headers, json=payload, timeout=15)
            response.raise_for_status()
            data = response.json()
            
            results = []
            for item in data.get('organic', [])[:num_results]:
                results.append({
                    'title': item.get('title', ''),
                    'url': item.get('link', ''),
                    'snippet': item.get('snippet', ''),
                    'source': 'Google (Serper API)'
                })
            
            logger.info(f"✓ Found {len(results)} results via Serper API")
            return results
            
        except Exception as e:
            logger.error(f"Serper API error: {e}. Falling back to DuckDuckGo")
            return self._search_with_duckduckgo(query, num_results)
    
    def _search_with_duckduckgo(self, query: str, num_results: int) -> List[Dict]:
        """Fallback: DuckDuckGo HTML scraping (FREE, no API key needed)"""
        try:
            url = "https://html.duckduckgo.com/html/"
            data = {'q': query, 'kl': 'us-en'}
            
            headers = {'Content-Type': 'application/x-www-form-urlencoded'}
            response = requests.post(url, data=data, headers=headers, timeout=15)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.text, 'html.parser')
            results = []
            
            for result in soup.find_all('div', class_='result')[:num_results]:
                title_elem = result.find('a', class_='result__a')
                snippet_elem = result.find('a', class_='result__snippet')
                
                if title_elem:
                    results.append({
                        'title': title_elem.get_text(strip=True),
                        'url': title_elem.get('href', ''),
                        'snippet': snippet_elem.get_text(strip=True) if snippet_elem else '',
                        'source': 'DuckDuckGo'
                    })
            
            logger.info(f"✓ Found {len(results)} results via DuckDuckGo")
            return results
            
        except Exception as e:
            logger.error(f"DuckDuckGo scraping error: {e}")
            return []


class LinkedInConnector(RealDataConnector):
    """Real LinkedIn data extraction"""
    
    def __init__(self, api_key=None):
        super().__init__()
        self.api_key = api_key
        
    def search_people(self, previous_company: str, role: str, new_company: Optional[str] = None) -> List[Dict]:
        """Search for REAL people who changed companies"""
        logger.info(f"Searching LinkedIn for: {role} from {previous_company}")
        
        if self.api_key:
            return self._search_with_proxycurl(previous_company, role, new_company)
        else:
            return self._search_with_google_dorks(previous_company, role, new_company)
    
    def _search_with_proxycurl(self, prev_company: str, role: str, new_company: Optional[str]) -> List[Dict]:
        """Use Proxycurl API for REAL LinkedIn data (Paid but accurate)"""
        try:
            url = "https://nubela.co/proxycurl/api/v2/search/person/"
            headers = {'Authorization': f'Bearer {self.api_key}'}
            
            params = {
                'past_company_name': prev_company,
                'title': role,
                'page_size': 10
            }
            
            if new_company:
                params['current_company_name'] = new_company
            
            response = requests.get(url, headers=headers, params=params, timeout=20)
            response.raise_for_status()
            data = response.json()
            
            results = []
            for person in data.get('results', []):
                results.append({
                    'name': f"{person.get('first_name', '')} {person.get('last_name', '')}".strip(),
                    'linkedin_url': person.get('linkedin_profile_url', ''),
                    'current_company': person.get('current_company_name', 'Unknown'),
                    'current_role': person.get('current_title', role),
                    'previous_company': prev_company,
                    'previous_role': role,
                    'location': person.get('location', ''),
                    'source': 'LinkedIn (Proxycurl API)'
                })
            
            logger.info(f"✓ Found {len(results)} REAL profiles via Proxycurl")
            return results
            
        except Exception as e:
            logger.error(f"Proxycurl API error: {e}. Falling back to Google dorks")
            return self._search_with_google_dorks(prev_company, role, new_company)
    
    def _search_with_google_dorks(self, prev_company: str, role: str, new_company: Optional[str]) -> List[Dict]:
        """Use Google dorks to find REAL LinkedIn profiles (FREE)"""
        try:
            google = GoogleSearchConnector(SERPER_API_KEY)
            
            # Generate targeted search queries
            queries = [
                f'site:linkedin.com/in/ "{prev_company}" "{role}" "current"',
                f'site:linkedin.com/in/ "former {role}" "{prev_company}"',
            ]
            
            if new_company:
                queries.insert(0, f'site:linkedin.com/in/ "{prev_company}" "{new_company}" "{role}"')
            
            all_results = []
            for query in queries[:2]:  # Limit queries to avoid rate limiting
                search_results = google.search(query, num_results=5)
                
                for result in search_results:
                    if 'linkedin.com/in/' in result['url']:
                        profile = self._parse_linkedin_snippet(result, prev_company, role)
                        if profile:
                            all_results.append(profile)
                
                time.sleep(2)  # Rate limiting between queries
            
            # Remove duplicates by LinkedIn URL
            unique_results = {r['linkedin_url']: r for r in all_results}.values()
            logger.info(f"✓ Found {len(unique_results)} REAL profiles via Google dorks")
            return list(unique_results)
            
        except Exception as e:
            logger.error(f"Google dork search error: {e}")
            return []
    
    def _parse_linkedin_snippet(self, result: Dict, prev_company: str, role: str) -> Optional[Dict]:
        """Extract REAL profile info from search snippet"""
        try:
            snippet = result.get('snippet', '')
            title = result.get('title', '')
            
            # Extract name (usually first part before dash)
            name_match = re.match(r'^([^-|]+)', title)
            name = name_match.group(1).strip() if name_match else 'Unknown'
            
            # Clean up name (remove LinkedIn suffix)
            name = re.sub(r'\s*-\s*LinkedIn.*$', '', name, flags=re.IGNORECASE).strip()
            
            # Try to find current company from snippet
            current_company = 'Unknown'
            current_role_found = role
            
            # Patterns to find current company
            company_patterns = [
                r'(?:at|@)\s+([A-Z][A-Za-z0-9\s&.,]+?)(?:\s+[-|•·]|\s*$)',
                r'(?:current|now)(?:\s+at)?\s+([A-Z][A-Za-z0-9\s&.,]+)',
                r'([A-Z][A-Za-z0-9\s&.,]+?)\s*[-|•·]\s*LinkedIn',
            ]
            
            snippet_text = title + " " + snippet
            for pattern in company_patterns:
                match = re.search(pattern, snippet_text)
                if match:
                    found_company = match.group(1).strip()
                    # Filter out generic terms
                    if found_company.lower() not in ['linkedin', 'profile', 'view', 'connect']:
                        current_company = found_company[:50]  # Limit length
                        break
            
            # Try to extract current role
            role_match = re.search(r'(CEO|CTO|CFO|COO|VP|Director|Manager|Executive|President|Head of|Chief)', 
                                 snippet_text, re.IGNORECASE)
            if role_match:
                current_role_found = role_match.group(0)
            
            return {
                'name': name,
                'linkedin_url': result['url'],
                'current_company': current_company,
                'current_role': current_role_found,
                'previous_company': prev_company,
                'previous_role': role,
                'snippet': snippet,
                'source': 'LinkedIn (Google Dorks)'
            }
            
        except Exception as e:
            logger.error(f"Failed to parse snippet: {e}")
            return None


class EmailFinderConnector(RealDataConnector):
    """Find and verify REAL email addresses"""
    
    def __init__(self, api_key=None):
        super().__init__()
        self.api_key = api_key
        
    def find_email(self, name: str, company: str, domain: str = None) -> Dict:
        """Find REAL email for a person"""
        logger.info(f"Finding email for: {name} at {company}")
        
        if self.api_key:
            result = self._find_with_hunter(name, company, domain)
            if result['email'] != 'unknown@unknown.com':
                return result
        
        # Always fallback to patterns if API doesn't find anything
        return self._find_with_patterns(name, company, domain)
    
    def _find_with_hunter(self, name: str, company: str, domain: str) -> Dict:
        """Use Hunter.io API to find REAL verified email (Paid)"""
        try:
            url = "https://api.hunter.io/v2/email-finder"
            
            # Generate domain if not provided
            if not domain:
                domain = company.lower().replace(' ', '').replace(',', '').replace('.', '')
                domain = re.sub(r'[^a-z0-9]', '', domain) + '.com'
            
            params = {
                'domain': domain,
                'full_name': name,
                'api_key': self.api_key
            }
            
            response = requests.get(url, params=params, timeout=15)
            response.raise_for_status()
            data = response.json()
            
            if data.get('data', {}).get('email'):
                score = data['data'].get('score', 0)
                return {
                    'email': data['data']['email'],
                    'confidence': score,
                    'confidence_level': 'High' if score > 80 else 'Medium' if score > 50 else 'Low',
                    'source': 'Hunter.io API (Verified)',
                    'verified': True
                }
            
            logger.info(f"Hunter.io: No email found for {name}")
            
        except Exception as e:
            logger.error(f"Hunter.io API error: {e}")
        
        return self._find_with_patterns(name, company, domain)
    
    def _find_with_patterns(self, name: str, company: str, domain: str) -> Dict:
        """Generate likely email using common patterns (FREE)"""
        try:
            # Parse name
            parts = name.lower().split()
            first = parts[0] if len(parts) > 0 else 'unknown'
            last = parts[-1] if len(parts) > 1 else 'user'
            
            # Generate domain
            if not domain:
                domain = company.lower().replace(' ', '').replace(',', '').replace('.', '').replace('inc', '').replace('llc', '')
                domain = re.sub(r'[^a-z0-9]', '', domain)
                # Try to extract main company name (first word usually)
                if len(domain) > 15:
                    domain = company.split()[0].lower()
                    domain = re.sub(r'[^a-z0-9]', '', domain)
                domain = domain + '.com'
            
            # Common patterns (in order of likelihood based on research)
            patterns = [
                f"{first}.{last}@{domain}",  # firstname.lastname@ (most common)
                f"{first}{last}@{domain}",   # firstnamelastname@
                f"{first[0]}{last}@{domain}", # flastname@
                f"{first}@{domain}",         # firstname@
                f"{first}_{last}@{domain}",  # firstname_lastname@
            ]
            
            # Return most likely pattern
            return {
                'email': patterns[0],
                'confidence': 60,
                'confidence_level': 'Medium',
                'source': 'Pattern Matching',
                'verified': False,
                'alternatives': patterns[1:3]
            }
            
        except Exception as e:
            logger.error(f"Pattern generation error: {e}")
            return {
                'email': 'unknown@unknown.com',
                'confidence': 0,
                'confidence_level': 'Low',
                'source': 'Error',
                'verified': False
            }


class PhoneFinderConnector(RealDataConnector):
    """Find REAL phone numbers through web scraping"""
    
    def find_phone(self, name: str, company: str, linkedin_url: str = None) -> Dict:
        """Attempt to find REAL phone number"""
        logger.info(f"Searching for phone number: {name}")
        
        # Try searching for contact pages
        google = GoogleSearchConnector(SERPER_API_KEY)
        
        queries = [
            f'"{name}" "{company}" phone contact',
            f'"{name}" contact site:{company.lower().replace(" ", "")}.com',
        ]
        
        for query in queries[:1]:  # Limit to 1 query to save time
            try:
                results = google.search(query, num_results=3)
                
                for result in results:
                    # Fetch page and extract phone
                    phone = self._extract_phone_from_url(result['url'])
                    if phone:
                        return {
                            'phone': phone,
                            'confidence': 'Medium',
                            'source': result['url']
                        }
                        
            except Exception as e:
                logger.error(f"Phone search error: {e}")
                continue
        
        return {
            'phone': 'Not Found',
            'confidence': 'Low',
            'source': 'No results'
        }
    
    def _extract_phone_from_url(self, url: str) -> Optional[str]:
        """Extract phone number from a webpage"""
        try:
            response = self.search_with_retry(url)
            if not response:
                return None
            
            text = response.text[:50000]  # Limit text size
            
            # Phone patterns (US and international)
            patterns = [
                r'\+?1?\s*\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}',
                r'\+\d{1,3}[\s.-]?\(?\d{2,4}\)?[\s.-]?\d{6,10}'
            ]
            
            for pattern in patterns:
                matches = re.findall(pattern, text)
                if matches:
                    # Return first valid phone number
                    phone = matches[0].strip()
                    if len(re.sub(r'\D', '', phone)) >= 10:  # At least 10 digits
                        return phone
                    
        except Exception as e:
            logger.error(f"Failed to extract phone from {url}: {e}")
        
        return None


class OSINTResearcher:
    """Main OSINT Research Orchestrator - NO DEMO DATA, REAL RESULTS ONLY"""
    
    def __init__(self):
        self.linkedin_connector = LinkedInConnector(PROXYCURL_API_KEY)
        self.email_connector = EmailFinderConnector(HUNTER_API_KEY)
        self.phone_connector = PhoneFinderConnector()
        
    def research_lead(self, previous_company: str, target_role: str, new_company: Optional[str] = None) -> Dict:
        """Main research orchestrator - Finds REAL leads"""
        
        logger.info("=" * 60)
        logger.info("🔍 Starting REAL OSINT Research...")
        logger.info(f"   Previous Company: {previous_company}")
        logger.info(f"   Target Role: {target_role}")
        logger.info(f"   New Company: {new_company or 'Any'}")
        logger.info("=" * 60)
        
        lead_data = {
            'search_criteria': {
                'previous_company': previous_company,
                'target_role': target_role,
                'new_company': new_company,
                'timestamp': datetime.now().isoformat()
            },
            'leads_found': [],
            'search_queries_used': [],
            'api_status': {
                'serper': 'Active' if SERPER_API_KEY else 'Using DuckDuckGo fallback',
                'proxycurl': 'Active' if PROXYCURL_API_KEY else 'Using Google dorks fallback',
                'hunter': 'Active' if HUNTER_API_KEY else 'Using pattern matching',
            }
        }
        
        # Step 1: Find profiles on LinkedIn
        logger.info("Step 1/3: Searching LinkedIn for profiles...")
        profiles = self.linkedin_connector.search_people(previous_company, target_role, new_company)
        
        if not profiles:
            logger.warning("⚠️  No profiles found. Try different search terms.")
            return lead_data
        
        logger.info(f"✓ Found {len(profiles)} profiles")
        
        # Step 2: Enrich each profile with contact information
        logger.info("Step 2/3: Enriching profiles with contact data...")
        
        for idx, profile in enumerate(profiles, 1):
            logger.info(f"   Processing {idx}/{len(profiles)}: {profile['name']}")
            
            # Find email
            email_data = self.email_connector.find_email(
                profile['name'],
                profile['current_company']
            )
            
            # Find phone (optional, can be slow)
            phone_data = {'phone': 'Not Found', 'confidence': 'Low'}
            # Uncomment to enable phone search (slower):
            # phone_data = self.phone_connector.find_phone(
            #     profile['name'],
            #     profile['current_company'],
            #     profile.get('linkedin_url')
            # )
            
            # Combine all data
            lead = {
                'name': profile['name'],
                'previous_company': profile['previous_company'],
                'previous_role': profile['previous_role'],
                'current_company': profile['current_company'],
                'current_role': profile['current_role'],
                'linkedin_url': profile['linkedin_url'],
                'estimated_email': email_data['email'],
                'email_confidence': email_data['confidence_level'],
                'email_verified': email_data.get('verified', False),
                'phone': phone_data['phone'],
                'phone_confidence': phone_data['confidence'],
                'data_sources': [profile['source'], email_data['source']],
                'last_updated': datetime.now().isoformat(),
                'notes': f"Found via {profile['source']}"
            }
            
            lead_data['leads_found'].append(lead)
        
        logger.info(f"✓ Enriched {len(lead_data['leads_found'])} leads with contact data")
        
        # Step 3: Generate summary
        logger.info("Step 3/3: Generating report...")
        logger.info("=" * 60)
        logger.info(f"✅ COMPLETED: Found {len(lead_data['leads_found'])} REAL leads")
        logger.info("=" * 60)
        
        return lead_data


class LLMProcessor:
    """LLM-based query processor"""
    
    def __init__(self, api_key):
        self.client = anthropic.Anthropic(api_key=api_key) if api_key else None
    
    def process_query(self, user_query: str) -> Dict:
        """Extract structured parameters from natural language query"""
        
        if not self.client:
            return self._simple_parse(user_query)
        
        try:
            message = self.client.messages.create(
                model="claude-sonnet-4-20250514",
                max_tokens=1000,
                messages=[{
                    "role": "user",
                    "content": f"""Extract lead research parameters from this query. Return ONLY a JSON object with these fields:
- previous_company: The company the person left (required)
- target_role: The job role/title to search for (required)
- new_company: The company they joined (or null if not specified)

Query: "{user_query}"

Return only valid JSON, no other text."""
                }]
            )
            
            response_text = message.content[0].text.strip()
            # Remove markdown code blocks if present
            if '```' in response_text:
                response_text = re.search(r'```(?:json)?\s*(\{.*?\})\s*```', response_text, re.DOTALL)
                if response_text:
                    response_text = response_text.group(1)
            
            params = json.loads(response_text)
            logger.info(f"LLM extracted: {params}")
            return params
            
        except Exception as e:
            logger.error(f"LLM processing error: {e}")
            return self._simple_parse(user_query)
    
    def _simple_parse(self, query: str) -> Dict:
        """Simple keyword-based parsing"""
        query_lower = query.lower()
        
        params = {
            'previous_company': None,
            'target_role': None,
            'new_company': None
        }
        
        # Extract companies
        if 'from' in query_lower and 'to' in query_lower:
            parts = query_lower.split('from')[1].split('to')
            if len(parts) == 2:
                params['previous_company'] = parts[0].strip()
                params['new_company'] = parts[1].strip()
        elif 'left' in query_lower:
            after_left = query_lower.split('left')[1].split()
            if after_left:
                params['previous_company'] = after_left[0].strip()
        
        # Extract role
        role_keywords = ['ceo', 'cto', 'cfo', 'coo', 'vp', 'director', 'manager', 'executive', 'officer', 'president', 'head']
        for keyword in role_keywords:
            if keyword in query_lower:
                params['target_role'] = keyword.upper() if len(keyword) <= 3 else keyword.title()
                break
        
        logger.info(f"Simple parse extracted: {params}")
        return params


# Initialize
osint_researcher = OSINTResearcher()
llm_processor = LLMProcessor(ANTHROPIC_API_KEY)

@app.route('/')
def index():
    """Main UI page"""
    return render_template('index.html')

@app.route('/api/research', methods=['POST'])
def research_leads():
    """API endpoint for lead research"""
    try:
        data = request.json
        query = data.get('query', '')
        
        if not query:
            return jsonify({'error': 'Query is required'}), 400
        
        # Process natural language query
        logger.info(f"📝 Processing query: {query}")
        params = llm_processor.process_query(query)
        
        if not params.get('previous_company') or not params.get('target_role'):
            return jsonify({
                'error': 'Could not extract required parameters. Please specify: previous company and role.',
                'example': 'Find CTOs who left Google and joined Tesla',
                'params_found': params
            }), 400
        
        # Conduct REAL OSINT research
        results = osint_researcher.research_lead(
            params['previous_company'],
            params['target_role'],
            params.get('new_company')
        )
        
        # Save to Excel if leads found
        if results['leads_found']:
            excel_path = save_to_excel(results)
            results['excel_file'] = os.path.basename(excel_path)
        else:
            results['excel_file'] = None
        
        return jsonify({
            'success': True,
            'results': results,
            'total_leads': len(results['leads_found'])
        })
        
    except Exception as e:
        logger.error(f"❌ Error: {str(e)}", exc_info=True)
        return jsonify({'error': str(e)}), 500

@app.route('/api/download/<filename>')
def download_file(filename):
    """Download generated Excel file"""
    file_path = os.path.join(OUTPUT_DIR, filename)
    if os.path.exists(file_path):
        return send_file(file_path, as_attachment=True)
    return jsonify({'error': 'File not found'}), 404

def save_to_excel(results):
    """Save results to Excel file"""
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    filename = f'leads_{timestamp}.xlsx'
    filepath = os.path.join(OUTPUT_DIR, filename)
    
    # Convert leads to DataFrame
    df = pd.DataFrame(results['leads_found'])
    
    # Create Excel writer
    with pd.ExcelWriter(filepath, engine='openpyxl') as writer:
        # Main leads sheet
        df.to_excel(writer, sheet_name='Leads', index=False)
        
        # Search criteria sheet
        criteria_df = pd.DataFrame([results['search_criteria']])
        criteria_df.to_excel(writer, sheet_name='Search Criteria', index=False)
        
        # API status sheet
        status_df = pd.DataFrame([results.get('api_status', {})])
        status_df.to_excel(writer, sheet_name='API Status', index=False)
    
    logger.info(f"✅ Excel file saved: {filepath}")
    return filepath

if __name__ == '__main__':
    print("\n" + "=" * 80)
    print("🚀 LEAD RESEARCH ORCHESTRATOR - REAL DATA VERSION")
    print("=" * 80)
    print(f"📁 Output Directory: {OUTPUT_DIR}")
    print(f"🤖 Anthropic Claude: {'✓ Active' if ANTHROPIC_API_KEY else '✗ Disabled (using fallback)'}")
    print(f"🔍 Google Search (Serper): {'✓ Active' if SERPER_API_KEY else '✗ Using DuckDuckGo'}")
    print(f"💼 LinkedIn (Proxycurl): {'✓ Active' if PROXYCURL_API_KEY else '✗ Using Google dorks'}")
    print(f"📧 Email Finder (Hunter): {'✓ Active' if HUNTER_API_KEY else '✗ Using pattern matching'}")
    print("=" * 80)
    print("⚠️  NO DEMO DATA - All results are REAL searches")
    print("💡 Get API keys at:")
    print("   • Serper.dev - Google search ($5/1000 searches)")
    print("   • Proxycurl - LinkedIn data ($0.01-0.10 per profile)")
    print("   • Hunter.io - Email finder (100 free/month)")
    print("=" * 80)
    print("🌐 Starting server on http://localhost:5000")
    print("=" * 80 + "\n")
    
    app.run(host='0.0.0.0', port=5000, debug=True, use_reloader=False)
