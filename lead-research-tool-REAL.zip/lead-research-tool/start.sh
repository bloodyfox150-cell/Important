#!/bin/bash

cd /home/claude/lead-research-tool

echo "Starting Lead Research Orchestrator..."
python3 app.py
