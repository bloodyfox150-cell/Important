#!/bin/bash

echo "================================================"
echo "Lead Research Orchestrator - Setup Script"
echo "================================================"
echo ""

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check Python
echo -e "${YELLOW}Checking Python installation...${NC}"
if ! command -v python3 &> /dev/null; then
    echo "Python 3 is not installed. Please install Python 3.8 or higher."
    exit 1
fi

PYTHON_VERSION=$(python3 --version | cut -d ' ' -f 2)
echo -e "${GREEN}✓ Python $PYTHON_VERSION found${NC}"
echo ""

# Install dependencies
echo -e "${YELLOW}Installing Python dependencies...${NC}"
pip3 install -r requirements.txt --break-system-packages

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Dependencies installed successfully${NC}"
else
    echo "Failed to install dependencies. Please check errors above."
    exit 1
fi
echo ""

# Create outputs directory
echo -e "${YELLOW}Creating output directory...${NC}"
mkdir -p outputs
echo -e "${GREEN}✓ Output directory created${NC}"
echo ""

# API Key prompt
echo -e "${YELLOW}LLM Setup (Optional)${NC}"
echo "For enhanced AI features, you can set up Claude API key."
echo "Visit: https://console.anthropic.com/settings/keys"
echo ""
read -p "Do you have an Anthropic API key? (y/n) " -n 1 -r
echo ""

if [[ $REPLY =~ ^[Yy]$ ]]; then
    read -p "Enter your API key: " API_KEY
    echo "export ANTHROPIC_API_KEY='$API_KEY'" >> ~/.bashrc
    export ANTHROPIC_API_KEY="$API_KEY"
    echo -e "${GREEN}✓ API key configured${NC}"
else
    echo "Skipping API key setup. Tool will use fallback parsing."
fi
echo ""

# Make app executable
chmod +x app.py

echo "================================================"
echo -e "${GREEN}Setup Complete!${NC}"
echo "================================================"
echo ""
echo "To start the application:"
echo "  python3 app.py"
echo ""
echo "Then open your browser to:"
echo "  http://localhost:5000"
echo ""
echo "For more information, see README.md"
echo "================================================"
