"""
Flask Backend Server for Ex-Employee Finder
Connects the frontend UI with the existing backend search logic
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import sys
import os

# Import the existing backend code
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Import functions from your existing code
import requests
import time
from typing import List, Dict
from dataclasses import asdict

app = Flask(__name__)
CORS(app)  # Enable CORS for frontend communication

# Import your existing classes and functions
# (These are from Improvedcode.py)

# We'll copy the essential classes and functions here
from dataclasses import dataclass

@dataclass
class Contact:
    """Contact with verified ex-employee status"""
    name: str
    linkedin_url: str
    current_company: str
    current_title: str
    previous_company: str
    position_level: str = None
    category: str = None
    profile_summary: str = None
    custom_email: str = None
    approach_plan: str = None
    snippet: str = None
    dork_used: str = None
    verified_ex_employee: bool = True
    
    def to_dict(self):
        return asdict(self)


class PositionClassifier:
    """Classify positions by seniority"""
    
    CXO = ['ceo', 'chief executive', 'president', 'founder', 'co-founder',
           'cto', 'chief technology', 'cfo', 'chief financial', 'coo', 
           'cmo', 'chief marketing', 'ciso', 'cio', 'cdo', 'cpo',
           'managing director', 'general manager']
    
    SENIOR = ['vp', 'vice president', 'svp', 'evp', 'director', 'head of',
              'senior director', 'executive director', 'partner', 'principal',
              'lead', 'senior lead', 'staff engineer', 'distinguished']
    
    MANAGER = ['manager', 'senior manager', 'team lead', 'project manager',
               'program manager', 'engineering manager']
    
    @staticmethod
    def classify(title: str) -> str:
        title_lower = title.lower()
        
        for keyword in PositionClassifier.CXO:
            if keyword in title_lower:
                return 'CXO'
        
        for keyword in PositionClassifier.SENIOR:
            if keyword in title_lower:
                return 'SENIOR'
        
        for keyword in PositionClassifier.MANAGER:
            if keyword in title_lower:
                return 'MANAGER'
        
        return 'OTHER'


# Google Dorks from your code
DORK_TEMPLATES = [
    'site:linkedin.com/in "Former {company}"',
    'site:linkedin.com/in "Ex {company}"',
    'site:linkedin.com/in "ex-employee" "{company}"',
    'site:linkedin.com/in "ex-employee at {company}"',
    'site:linkedin.com/in "ex- {company}"',
    'site:linkedin.com/in "previously at {company}"',
    'site:linkedin.com/in "previously worked at {company}"',
    'site:linkedin.com/in "formerly at {company}"',
    'site:linkedin.com/in "formerly worked at {company}"',
    'site:linkedin.com/in "worked at {company}" -"Present"',
    'site:linkedin.com/in "Worked at {company}" "until"',
    'site:linkedin.com/in "Past: {company}"',
    'site:linkedin.com/in "Past companies" "{company}"',
    'site:linkedin.com/in "past employer" "{company}"',
    'site:linkedin.com/in "left {company}"',
    'site:linkedin.com/in "left {company} in"',
    'site:linkedin.com/in "experience at {company}" -"Present"',
    'site:linkedin.com/in "{company}" "2015 - 2019"',
    'site:linkedin.com/in "{company}" "2016 - 2020"',
    'site:linkedin.com/in "{company}" "2017 - 2021"',
    'site:linkedin.com/in "Former employee at {company}"',
    'site:linkedin.com/in "ex-staffer" "{company}"',
    'site:linkedin.com/in "ex-team member" "{company}"',
    'site:linkedin.com/in "ex-manager" "{company}"',
    'site:linkedin.com/in "ex-engineer" "{company}"',
    'site:linkedin.com/in "ex-analyst" "{company}"',
    'site:linkedin.com/in "ex-consultant" "{company}"',
    'site:linkedin.com/in "ex-intern" "{company}"',
    'site:linkedin.com/in "alumni of {company}"',
    'site:linkedin.com/in "alumnus of {company}"',
    'site:linkedin.com/in "used to work at {company}"',
    'site:linkedin.com/in "used to work for" "{company}"',
    'site:linkedin.com/in "have worked at" "{company}"',
    'site:linkedin.com/in "have worked for" "{company}"',
    'site:linkedin.com/in "previous experience" "{company}"',
    'site:linkedin.com/in "prior experience" "{company}"',
    'site:linkedin.com/in "earlier worked at" "{company}"',
    'site:linkedin.com/in "earlier with" "{company}"',
    'site:linkedin.com/in "tenure at" "{company}"',
    'site:linkedin.com/in "stint at" "{company}"',
    'site:linkedin.com/in "ex {company} employee"',
    'site:linkedin.com/in "ex {company} engineer"',
    'site:linkedin.com/in "ex {company} analyst"',
    'site:linkedin.com/in "ex {company} manager"',
    'site:linkedin.com/in "ex {company} consultant"',
    'site:linkedin.com/in "ex {company} developer"',
    'site:linkedin.com/in "ex {company} staff"',
    'site:linkedin.com/in "left {company}" "joined"',
    'site:linkedin.com/in "formerly with {company}"',
    'site:linkedin.com/in "past role at" "{company}"',
    'site:linkedin.com/in intitle:"Former {company}"',
    'site:linkedin.com/in intitle:"Ex {company}"',
    'site:linkedin.com/in intitle:"{company}" "Former"',
    'site:linkedin.com/in intext:"Former {company}"',
    'site:linkedin.com/in intext:"Previously at {company}"',
    'site:linkedin.com/in intext:"Ex-employee of {company}"',
    'site:linkedin.com/in intext:"alumni of {company}"',
    'site:linkedin.com/in "experience" "Former {company}"',
    'site:linkedin.com/in "Summary" "Former {company}"',
    'site:linkedin.com/in "About" "Previously at {company}"',
]


def search_with_dork(dork_query: str, api_key: str, num_results: int = 5) -> List[Dict]:
    """Search using a specific Google dork"""
    
    params = {
        "engine": "google",
        "q": dork_query,
        "api_key": api_key,
        "num": num_results
    }
    
    try:
        response = requests.get("https://www.searchapi.io/api/v1/search", params=params, timeout=30)
        response.raise_for_status()
        data = response.json()
        
        results = data.get('organic_results', [])
        return results
        
    except Exception as e:
        print(f"Search error: {e}")
        return []


def is_still_working(snippet: str, title: str, company_name: str) -> bool:
    """Check if person is STILL working at the company"""
    
    text = (snippet + " " + title).lower()
    company_lower = company_name.lower()
    
    current_indicators = [
        f'current', f'present', f'currently at {company_lower}',
        f'working at {company_lower}', f'employed at {company_lower}',
        f'now at {company_lower}', f'at {company_lower} since'
    ]
    
    for indicator in current_indicators:
        if indicator in text and company_lower in text:
            return True
    
    return False


def extract_current_position(snippet: str, title: str) -> tuple:
    """Extract current title and company"""
    
    current_title = "Unknown"
    current_company = "Unknown"
    
    if " at " in snippet:
        parts = snippet.split(" at ")
        if len(parts) >= 2:
            current_title = parts[0].split("·")[-1].strip() if "·" in parts[0] else parts[0].strip()
            current_company = parts[1].split("·")[0].split("-")[0].strip()
    
    elif " - " in title:
        parts = title.split(" - ")
        if len(parts) >= 2:
            current_title = parts[1].strip()
            if len(parts) >= 3:
                current_company = parts[2].strip()
    
    return current_title, current_company


def multi_dork_search(company_name: str, api_key: str, dorks_to_use: int = 60, 
                     results_per_dork: int = 5) -> Dict[str, List[Contact]]:
    """Execute multi-dork search"""
    
    print(f"\nStarting multi-dork search for: {company_name}")
    print(f"Using {dorks_to_use} dorks, {results_per_dork} results each")
    
    all_results = {}
    unique_linkedin_urls = set()
    total_found = 0
    total_verified_ex = 0
    
    # Use specified number of dorks
    dorks_to_search = DORK_TEMPLATES[:dorks_to_use]
    
    for i, dork_template in enumerate(dorks_to_search, 1):
        dork = dork_template.format(company=company_name)
        
        print(f"\n[{i}/{dorks_to_use}] Searching: {dork[:70]}...")
        
        results = search_with_dork(dork, api_key, results_per_dork)
        
        if not results:
            print("    No results")
            continue
        
        print(f"    Found {len(results)} results, filtering...")
        
        dork_contacts = []
        
        for result in results:
            link = result.get('link', '')
            title = result.get('title', '')
            snippet = result.get('snippet', '')
            
            if not link or not title:
                continue
            
            if link in unique_linkedin_urls:
                continue
            
            if is_still_working(snippet, title, company_name):
                print(f"    ⚠️  Skipping (still working): {title[:50]}...")
                continue
            
            name = title.split(' - ')[0].strip() if ' - ' in title else title.split('|')[0].strip()
            current_title, current_company = extract_current_position(snippet, title)
            position_level = PositionClassifier.classify(current_title)
            
            contact = Contact(
                name=name,
                linkedin_url=link,
                current_company=current_company,
                current_title=current_title,
                previous_company=company_name,
                position_level=position_level,
                snippet=snippet,
                dork_used=dork,
                verified_ex_employee=True
            )
            
            dork_contacts.append(contact)
            unique_linkedin_urls.add(link)
            total_found += 1
            total_verified_ex += 1
        
        if dork_contacts:
            all_results[dork] = dork_contacts
            print(f"    ✓ Added {len(dork_contacts)} verified ex-employees")
        
        time.sleep(2)  # Rate limiting
    
    print(f"\nSearch complete: {total_verified_ex} unique ex-employees found")
    
    return all_results


@app.route('/api/search', methods=['POST'])
def search():
    """API endpoint for searching ex-employees"""
    
    try:
        data = request.json
        
        # Extract parameters
        company_name = data.get('companyName')
        searchapi_key = data.get('searchapiKey')
        anthropic_key = data.get('anthropicKey')
        results_per_dork = data.get('resultsPerDork', 5)
        max_dorks = data.get('maxDorks', 60)
        position_level = data.get('positionLevel', 'OTHER')
        
        # Validate inputs
        if not company_name or not searchapi_key:
            return jsonify({'error': 'Missing required parameters'}), 400
        
        print(f"\n=== API REQUEST ===")
        print(f"Company: {company_name}")
        print(f"Max Dorks: {max_dorks}")
        print(f"Results/Dork: {results_per_dork}")
        print(f"Position Filter: {position_level}")
        
        # Perform search
        dork_results = multi_dork_search(
            company_name=company_name,
            api_key=searchapi_key,
            dorks_to_use=max_dorks,
            results_per_dork=results_per_dork
        )
        
        # Flatten results
        all_contacts = []
        for dork, contacts in dork_results.items():
            all_contacts.extend(contacts)
        
        # Remove duplicates
        seen_urls = set()
        unique_contacts = []
        for contact in all_contacts:
            if contact.linkedin_url not in seen_urls:
                unique_contacts.append(contact)
                seen_urls.add(contact.linkedin_url)
        
        # Filter by position if needed
        if position_level != "OTHER":
            level_order = {'CXO': 0, 'SENIOR': 1, 'MANAGER': 2, 'OTHER': 3}
            min_priority = level_order.get(position_level, 3)
            
            unique_contacts = [
                c for c in unique_contacts
                if level_order.get(c.position_level, 4) <= min_priority
            ]
        
        # Convert to dict
        results = [contact.to_dict() for contact in unique_contacts]
        
        print(f"\n=== SEARCH COMPLETE ===")
        print(f"Total contacts found: {len(results)}")
        
        return jsonify({
            'success': True,
            'results': results,
            'count': len(results)
        })
        
    except Exception as e:
        print(f"Error: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500


@app.route('/api/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({'status': 'healthy', 'message': 'Backend is running'})


if __name__ == '__main__':
    print("\n" + "="*80)
    print(" EX-EMPLOYEE FINDER - BACKEND SERVER")
    print("="*80)
    print("\n🚀 Starting Flask server...")
    print("📡 Frontend should connect to: http://localhost:5000")
    print("💡 Open index.html in your browser to use the app")
    print("\n" + "="*80 + "\n")
    
    app.run(debug=True, host='0.0.0.0', port=5000)
