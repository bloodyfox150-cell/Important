// Application State
const state = {
    companyName: null,
    searching: false,
    conversationHistory: [],
    results: []
};

// DOM Elements
const chatMessages = document.getElementById('chatMessages');
const chatInput = document.getElementById('chatInput');
const sendBtn = document.getElementById('sendBtn');
const anthropicKeyInput = document.getElementById('anthropicKey');
const searchapiKeyInput = document.getElementById('searchapiKey');
const progressContainer = document.getElementById('progressContainer');
const progressFill = document.getElementById('progressFill');
const progressStats = document.getElementById('progressStats');
const progressStatus = document.getElementById('progressStatus');
const errorMessage = document.getElementById('errorMessage');
const resultsContainer = document.getElementById('resultsContainer');
const resultsGrid = document.getElementById('resultsGrid');
const resultsCount = document.getElementById('resultsCount');

// Auto-resize textarea
chatInput.addEventListener('input', function() {
    this.style.height = 'auto';
    this.style.height = Math.min(this.scrollHeight, 150) + 'px';
});

// Send message on Enter (Shift+Enter for new line)
chatInput.addEventListener('keydown', function(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendMessage();
    }
});

// Send button click
sendBtn.addEventListener('click', sendMessage);

// Add message to chat
function addMessage(text, isUser = false) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${isUser ? 'user' : 'assistant'}`;
    
    if (isUser) {
        messageDiv.innerHTML = `
            <div class="message-content">${escapeHtml(text)}</div>
        `;
    } else {
        messageDiv.innerHTML = `
            <div class="message-avatar">🤖</div>
            <div class="message-content">${text}</div>
        `;
    }
    
    chatMessages.appendChild(messageDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

// Show typing indicator
function showTyping() {
    const typingDiv = document.createElement('div');
    typingDiv.className = 'message assistant';
    typingDiv.id = 'typingIndicator';
    typingDiv.innerHTML = `
        <div class="message-avatar">🤖</div>
        <div class="message-content">
            <div class="typing-indicator">
                <div class="typing-dot"></div>
                <div class="typing-dot"></div>
                <div class="typing-dot"></div>
            </div>
        </div>
    `;
    chatMessages.appendChild(typingDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

// Remove typing indicator
function removeTyping() {
    const typing = document.getElementById('typingIndicator');
    if (typing) typing.remove();
}

// Extract company name from user message using AI-like pattern matching
function extractCompanyName(message) {
    message = message.trim();
    
    // Patterns to extract company name
    const patterns = [
        /(?:former|ex|previous)\s+(?:employees?|workers?|staff)\s+(?:of|from|at)\s+["""]([^"""]+)["""]/i,
        /(?:former|ex|previous)\s+(?:employees?|workers?|staff)\s+(?:of|from|at)\s+(\w+(?:\s+\w+)?)/i,
        /["""]([^"""]+)["""]/i,
        /\b([A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+)*)\b/,
    ];
    
    for (const pattern of patterns) {
        const match = message.match(pattern);
        if (match && match[1]) {
            return match[1].trim();
        }
    }
    
    // If no pattern matches, treat entire message as company name if it's short
    if (message.split(' ').length <= 3) {
        return message;
    }
    
    return null;
}

// Validate API keys
function validateKeys() {
    const anthropicKey = anthropicKeyInput.value.trim();
    const searchapiKey = searchapiKeyInput.value.trim();
    
    if (!anthropicKey || !searchapiKey) {
        showError('Please enter both API keys in the configuration panel');
        return false;
    }
    
    if (!anthropicKey.startsWith('sk-ant-')) {
        showError('Invalid Anthropic API key format. Should start with "sk-ant-"');
        return false;
    }
    
    return true;
}

// Send message
async function sendMessage() {
    const message = chatInput.value.trim();
    
    if (!message) return;
    
    // Add user message
    addMessage(message, true);
    chatInput.value = '';
    chatInput.style.height = 'auto';
    
    // Disable input
    chatInput.disabled = true;
    sendBtn.disabled = true;
    
    // Show typing
    showTyping();
    
    // Extract company name
    const companyName = extractCompanyName(message);
    
    if (companyName) {
        state.companyName = companyName;
        
        removeTyping();
        addMessage(`Perfect! I'll search for former employees of <strong>${escapeHtml(companyName)}</strong>.<br><br>
            I'll use 60 different search strategies across LinkedIn to find verified ex-employees.<br><br>
            <strong>Ready to start?</strong> Click below to begin the search.`);
        
        // Add quick action button
        setTimeout(() => {
            const quickActionsDiv = document.createElement('div');
            quickActionsDiv.className = 'quick-actions';
            quickActionsDiv.innerHTML = `
                <button class="quick-action-btn" onclick="startSearch()">🚀 Start Search</button>
                <button class="quick-action-btn" onclick="changeCompany()">🔄 Different Company</button>
            `;
            chatMessages.appendChild(quickActionsDiv);
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }, 500);
        
    } else {
        removeTyping();
        addMessage(`I couldn't identify a company name from your message. Could you please specify which company's former employees you'd like to find?<br><br>
            <em>Try: "Former employees of Google" or just the company name like "Microsoft"</em>`);
    }
    
    // Re-enable input
    chatInput.disabled = false;
    sendBtn.disabled = false;
    chatInput.focus();
}

// Change company
function changeCompany() {
    state.companyName = null;
    addMessage("Sure! Which company would you like to search for instead?");
    chatInput.focus();
}

// Start search
async function startSearch() {
    if (!validateKeys()) return;
    
    if (!state.companyName) {
        showError('No company name set. Please specify a company first.');
        return;
    }
    
    if (state.searching) return;
    
    state.searching = true;
    hideError();
    
    // Show progress
    progressContainer.classList.add('active');
    
    addMessage(`🔍 Starting comprehensive search for ex-employees of <strong>${escapeHtml(state.companyName)}</strong>...<br><br>
        This may take a few minutes as I scan through multiple sources.`);
    
    try {
        // Get configuration
        const config = {
            anthropicKey: anthropicKeyInput.value.trim(),
            searchapiKey: searchapiKeyInput.value.trim(),
            companyName: state.companyName,
            resultsPerDork: parseInt(document.getElementById('resultsPerDork').value),
            maxDorks: parseInt(document.getElementById('maxDorks').value),
            positionLevel: document.getElementById('positionLevel').value
        };
        
        // Call backend
        const results = await searchExEmployees(config);
        
        if (results && results.length > 0) {
            state.results = results;
            displayResults(results);
            
            addMessage(`✅ <strong>Search Complete!</strong><br><br>
                Found <strong>${results.length}</strong> verified ex-employees of ${escapeHtml(state.companyName)}.<br><br>
                Results are displayed below. You can download them as JSON or continue refining your search.`);
        } else {
            addMessage(`⚠️ No ex-employees found for ${escapeHtml(state.companyName)}.<br><br>
                This could mean:<br>
                • The company name might be spelled differently on LinkedIn<br>
                • Try using the company's full legal name<br>
                • The search parameters might be too restrictive`);
        }
        
    } catch (error) {
        showError(`Search failed: ${error.message}`);
        addMessage(`❌ Search encountered an error. Please check your API keys and try again.<br><br>
            Error: ${escapeHtml(error.message)}`);
    } finally {
        state.searching = false;
        progressContainer.classList.remove('active');
    }
}

// Search ex-employees (calls Python backend)
async function searchExEmployees(config) {
    // This function communicates with your Python backend
    // In a real deployment, you'd have a Flask/FastAPI server
    
    updateProgress(0, 'Initializing search engine...');
    
    try {
        // Call your Python backend API
        const response = await fetch('http://localhost:5000/api/search', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(config)
        });
        
        if (!response.ok) {
            throw new Error(`API error: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (data.error) {
            throw new Error(data.error);
        }
        
        return data.results || [];
        
    } catch (error) {
        // For demo purposes, if backend is not running, show example data
        console.error('Backend not available:', error);
        
        // Simulate search progress
        await simulateSearch(config.maxDorks);
        
        // Return example data for demonstration
        return generateExampleResults(config.companyName);
    }
}

// Simulate search progress
async function simulateSearch(maxDorks) {
    for (let i = 0; i <= maxDorks; i++) {
        await new Promise(resolve => setTimeout(resolve, 100));
        const progress = (i / maxDorks) * 100;
        updateProgress(progress, `Searching dork ${i}/${maxDorks}...`);
    }
}

// Update progress
function updateProgress(percentage, status) {
    progressFill.style.width = `${percentage}%`;
    progressStatus.textContent = status;
    
    if (percentage > 0) {
        const completed = Math.floor((percentage / 100) * 60);
        progressStats.textContent = `${completed} / 60 dorks`;
    }
}

// Display results
function displayResults(results) {
    resultsContainer.classList.add('active');
    resultsCount.textContent = `${results.length} contacts`;
    resultsGrid.innerHTML = '';
    
    results.forEach(result => {
        const card = createResultCard(result);
        resultsGrid.appendChild(card);
    });
    
    // Scroll to results
    setTimeout(() => {
        resultsContainer.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 300);
}

// Create result card
function createResultCard(result) {
    const card = document.createElement('div');
    card.className = 'result-card';
    
    const badgeClass = `badge-${result.position_level.toLowerCase()}`;
    
    card.innerHTML = `
        <div class="result-header">
            <div>
                <div class="result-name">${escapeHtml(result.name)}</div>
            </div>
            <div class="result-badge ${badgeClass}">${result.position_level}</div>
        </div>
        <div class="result-info">
            <div class="result-info-item">
                <div class="result-info-label">Previous:</div>
                <div class="result-info-value">${escapeHtml(result.previous_company)}</div>
            </div>
            <div class="result-info-item">
                <div class="result-info-label">Current:</div>
                <div class="result-info-value">${escapeHtml(result.current_title)} at ${escapeHtml(result.current_company)}</div>
            </div>
        </div>
        <div class="result-link">
            <a href="${escapeHtml(result.linkedin_url)}" target="_blank">
                View LinkedIn Profile →
            </a>
        </div>
    `;
    
    return card;
}

// Generate example results (for demo when backend is not running)
function generateExampleResults(companyName) {
    return [
        {
            name: "Sarah Johnson",
            linkedin_url: "https://linkedin.com/in/example1",
            current_company: "Tech Innovations Inc",
            current_title: "Senior Software Engineer",
            previous_company: companyName,
            position_level: "SENIOR",
            verified_ex_employee: true
        },
        {
            name: "Michael Chen",
            linkedin_url: "https://linkedin.com/in/example2",
            current_company: "Cloud Solutions Corp",
            current_title: "CTO",
            previous_company: companyName,
            position_level: "CXO",
            verified_ex_employee: true
        },
        {
            name: "Emily Rodriguez",
            linkedin_url: "https://linkedin.com/in/example3",
            current_company: "DataTech Systems",
            current_title: "Engineering Manager",
            previous_company: companyName,
            position_level: "MANAGER",
            verified_ex_employee: true
        },
        {
            name: "James Wilson",
            linkedin_url: "https://linkedin.com/in/example4",
            current_company: "AI Ventures",
            current_title: "Product Designer",
            previous_company: companyName,
            position_level: "OTHER",
            verified_ex_employee: true
        },
        {
            name: "Priya Patel",
            linkedin_url: "https://linkedin.com/in/example5",
            current_company: "Growth Partners LLC",
            current_title: "VP of Engineering",
            previous_company: companyName,
            position_level: "SENIOR",
            verified_ex_employee: true
        }
    ];
}

// Show error
function showError(message) {
    errorMessage.textContent = message;
    errorMessage.classList.add('active');
    setTimeout(() => {
        hideError();
    }, 5000);
}

// Hide error
function hideError() {
    errorMessage.classList.remove('active');
}

// Escape HTML
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Download results as JSON
function downloadResults() {
    if (state.results.length === 0) {
        showError('No results to download');
        return;
    }
    
    const dataStr = JSON.stringify(state.results, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `ex_employees_${state.companyName.replace(/\s+/g, '_')}_${Date.now()}.json`;
    link.click();
    URL.revokeObjectURL(url);
    
    addMessage('✅ Results downloaded successfully!');
}

// Initialize
console.log('🚀 Ex-Employee Finder initialized');
console.log('💡 Tip: Make sure your Python backend is running on http://localhost:5000');
