#!/bin/bash

# Quick Start Script for Ex-Employee Finder

echo "======================================"
echo "  Ex-Employee Finder - Setup"
echo "======================================"
echo ""

# Check Python installation
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed. Please install Python 3.7 or higher."
    exit 1
fi

echo "✓ Python 3 found"

# Install dependencies
echo ""
echo "📦 Installing dependencies..."
pip install -r requirements.txt

if [ $? -eq 0 ]; then
    echo "✓ Dependencies installed successfully"
else
    echo "❌ Failed to install dependencies"
    exit 1
fi

# Start the backend
echo ""
echo "======================================"
echo "  Starting Backend Server"
echo "======================================"
echo ""
echo "🚀 Backend will start on http://localhost:5000"
echo "💡 Open index.html in your browser to use the app"
echo ""
echo "Press Ctrl+C to stop the server"
echo ""

python3 backend_server.py
