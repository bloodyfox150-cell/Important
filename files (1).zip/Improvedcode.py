"""
===============================================================================
ADVANCED EX-EMPLOYEE FINDER - MULTI-DORK SEARCH
===============================================================================

Uses 60+ Google dorks to find ACTUAL ex-employees (people who LEFT the company)
Scrapes top 5 results from each dork for comprehensive coverage
Verifies employment status before including in results

QUICK START:
1. Set API keys in lines 25-26
2. Run: python advanced_ex_employee_finder.py
3. Enter company name when prompted
4. Wait for results

===============================================================================
"""

import json
import requests
import time
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass, asdict
import re
from datetime import datetime

# ============================================================================
#  API CONFIGURATION - CHANGE YOUR KEYS HERE
# ============================================================================
ANTHROPIC_API_KEY = "************"
SEARCHAPI_KEY = "************************"

# ============================================================================
# SEARCH CONFIGURATION
# ============================================================================
RESULTS_PER_DORK = 5          # Top N results per dork query
MAX_DORKS_TO_USE = 60         # How many dorks to use (1-60)
DELAY_BETWEEN_SEARCHES = 2    # Seconds between searches (rate limiting)
MIN_POSITION_LEVEL = "OTHER"  # CXO, SENIOR, MANAGER, or OTHER
OUTPUT_FILE = "verified_ex_employees.json"

# ============================================================================
# GOOGLE DORKS - 60 VARIATIONS TO FIND EX-EMPLOYEES
# ============================================================================
DORK_TEMPLATES = [
    'site:linkedin.com/in "Former {company}"',
    'site:linkedin.com/in "Ex {company}"',
    'site:linkedin.com/in "ex-employee" "{company}"',
    'site:linkedin.com/in "ex-employee at {company}"',
    'site:linkedin.com/in "ex- {company}"',
    'site:linkedin.com/in "previously at {company}"',
    'site:linkedin.com/in "previously worked at {company}"',
    'site:linkedin.com/in "formerly at {company}"',
    'site:linkedin.com/in "formerly worked at {company}"',
    'site:linkedin.com/in "worked at {company}" -"Present"',
    'site:linkedin.com/in "Worked at {company}" "until"',
    'site:linkedin.com/in "Past: {company}"',
    'site:linkedin.com/in "Past companies" "{company}"',
    'site:linkedin.com/in "past employer" "{company}"',
    'site:linkedin.com/in "left {company}"',
    'site:linkedin.com/in "left {company} in"',
    'site:linkedin.com/in "experience at {company}" -"Present"',
    'site:linkedin.com/in "{company}" "2015 - 2019"',
    'site:linkedin.com/in "{company}" "2016 - 2020"',
    'site:linkedin.com/in "{company}" "2017 - 2021"',
    'site:linkedin.com/in "Former employee at {company}"',
    'site:linkedin.com/in "ex-staffer" "{company}"',
    'site:linkedin.com/in "ex-team member" "{company}"',
    'site:linkedin.com/in "ex-manager" "{company}"',
    'site:linkedin.com/in "ex-engineer" "{company}"',
    'site:linkedin.com/in "ex-analyst" "{company}"',
    'site:linkedin.com/in "ex-consultant" "{company}"',
    'site:linkedin.com/in "ex-intern" "{company}"',
    'site:linkedin.com/in "alumni of {company}"',
    'site:linkedin.com/in "alumnus of {company}"',
    'site:linkedin.com/in "used to work at {company}"',
    'site:linkedin.com/in "used to work for" "{company}"',
    'site:linkedin.com/in "have worked at" "{company}"',
    'site:linkedin.com/in "have worked for" "{company}"',
    'site:linkedin.com/in "previous experience" "{company}"',
    'site:linkedin.com/in "prior experience" "{company}"',
    'site:linkedin.com/in "earlier worked at" "{company}"',
    'site:linkedin.com/in "earlier with" "{company}"',
    'site:linkedin.com/in "tenure at" "{company}"',
    'site:linkedin.com/in "stint at" "{company}"',
    'site:linkedin.com/in "ex {company} employee"',
    'site:linkedin.com/in "ex {company} engineer"',
    'site:linkedin.com/in "ex {company} analyst"',
    'site:linkedin.com/in "ex {company} manager"',
    'site:linkedin.com/in "ex {company} consultant"',
    'site:linkedin.com/in "ex {company} developer"',
    'site:linkedin.com/in "ex {company} staff"',
    'site:linkedin.com/in "left {company}" "joined"',
    'site:linkedin.com/in "formerly with {company}"',
    'site:linkedin.com/in "past role at" "{company}"',
    'site:linkedin.com/in intitle:"Former {company}"',
    'site:linkedin.com/in intitle:"Ex {company}"',
    'site:linkedin.com/in intitle:"{company}" "Former"',
    'site:linkedin.com/in intext:"Former {company}"',
    'site:linkedin.com/in intext:"Previously at {company}"',
    'site:linkedin.com/in intext:"Ex-employee of {company}"',
    'site:linkedin.com/in intext:"alumni of {company}"',
    'site:linkedin.com/in "experience" "Former {company}"',
    'site:linkedin.com/in "Summary" "Former {company}"',
    'site:linkedin.com/in "About" "Previously at {company}"',
]

# Check API keys
if ANTHROPIC_API_KEY == "your-anthropic-api-key-here" or SEARCHAPI_KEY == "your-searchapi-key-here":
    print("\n" + "="*80)
    print("⚠️  ERROR: Please set your API keys")
    print("="*80)
    print("\nEdit this file and change:")
    print('  Line 25: ANTHROPIC_API_KEY = "your-key"')
    print('  Line 26: SEARCHAPI_KEY = "your-key"')
    print("\nGet keys from:")
    print("  - Anthropic: https://console.anthropic.com/")
    print("  - SearchAPI: https://www.searchapi.io/")
    print()
    exit(1)

# Import dependencies
try:
    import anthropic
except ImportError:
    print("Installing anthropic...")
    import subprocess
    subprocess.check_call(['pip', 'install', '-q', 'anthropic'])
    import anthropic


@dataclass
class Contact:
    """Contact with verified ex-employee status"""
    name: str
    linkedin_url: str
    current_company: str
    current_title: str
    previous_company: str
    position_level: Optional[str] = None
    category: Optional[str] = None
    profile_summary: Optional[str] = None
    custom_email: Optional[str] = None
    approach_plan: Optional[str] = None
    snippet: Optional[str] = None
    dork_used: Optional[str] = None
    verified_ex_employee: bool = True  # Only true ex-employees included
    
    def to_dict(self):
        return asdict(self)


class PositionClassifier:
    """Classify positions by seniority"""
    
    CXO = ['ceo', 'chief executive', 'president', 'founder', 'co-founder',
           'cto', 'chief technology', 'cfo', 'chief financial', 'coo', 
           'cmo', 'chief marketing', 'ciso', 'cio', 'cdo', 'cpo',
           'managing director', 'general manager']
    
    SENIOR = ['vp', 'vice president', 'svp', 'evp', 'director', 'head of',
              'senior director', 'executive director', 'partner', 'principal',
              'lead', 'senior lead', 'staff engineer', 'distinguished']
    
    MANAGER = ['manager', 'senior manager', 'team lead', 'project manager',
               'program manager', 'engineering manager']
    
    @staticmethod
    def classify(title: str) -> str:
        title_lower = title.lower()
        
        for keyword in PositionClassifier.CXO:
            if keyword in title_lower:
                return 'CXO'
        
        for keyword in PositionClassifier.SENIOR:
            if keyword in title_lower:
                return 'SENIOR'
        
        for keyword in PositionClassifier.MANAGER:
            if keyword in title_lower:
                return 'MANAGER'
        
        return 'OTHER'


def search_with_dork(dork_query: str, api_key: str, num_results: int = 5) -> List[Dict]:
    """Search using a specific Google dork"""
    
    params = {
        "engine": "google",
        "q": dork_query,
        "api_key": api_key,
        "num": num_results
    }
    
    try:
        response = requests.get("https://www.searchapi.io/api/v1/search", params=params, timeout=30)
        response.raise_for_status()
        data = response.json()
        
        results = data.get('organic_results', [])
        return results
        
    except Exception as e:
        print(f"      ✗ Search error: {e}")
        return []


def is_still_working(snippet: str, title: str, company_name: str) -> bool:
    """
    Check if person is STILL working at the company
    Returns True if STILL working (should be filtered out)
    Returns False if LEFT (should be included)
    """
    
    text = f"{title} {snippet}".lower()
    company_lower = company_name.lower()
    
    # Strong indicators they're STILL working (exclude these)
    still_working_indicators = [
        'present',
        'current',
        'currently at',
        f'at {company_lower}',
        '- present',
        'to present',
        '- now',
        'to now',
        f'{company_lower} ·',  # LinkedIn format for current job
    ]
    
    for indicator in still_working_indicators:
        if indicator in text:
            # Check if company name is near this indicator
            if company_lower in text[max(0, text.find(indicator)-50):text.find(indicator)+50]:
                return True  # Still working - exclude
    
    # Strong indicators they LEFT (include these)
    left_indicators = [
        'former',
        'ex-',
        'previously',
        'formerly',
        'past',
        'left',
        'until',
        'alumni',
        'used to',
        'have worked',
        'had worked',
        'was at',
        'were at',
        'tenure',
        'stint',
    ]
    
    has_left_indicator = False
    for indicator in left_indicators:
        if indicator in text and company_lower in text:
            has_left_indicator = True
            break
    
    # Check for date ranges that ended (2020-2023, etc.)
    date_range_pattern = r'\d{4}\s*[-–]\s*\d{4}'
    if re.search(date_range_pattern, text):
        # Has a date range that ended - likely left
        if company_lower in text:
            return False  # Left - include
    
    # If has "left" indicator and no "still working" indicator
    if has_left_indicator:
        return False  # Left - include
    
    # Default: if unclear, assume still working (be conservative)
    return True


def extract_current_position(snippet: str, title: str) -> Tuple[str, str]:
    """Extract CURRENT title and company"""
    
    text = f"{title} {snippet}"
    
    # Common LinkedIn patterns for current position
    patterns = [
        r'([^-|]+?)\s+at\s+([^-|•·]+?)(?:\s*[-|•·]|$)',
        r'([^-|]+?)\s*\|\s*([^-|•·]+)',
        r'Current[ly]?:\s*([^-|]+?)\s+at\s+([^-|•·]+)',
    ]
    
    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            title = match.group(1).strip()
            company = match.group(2).strip()
            
            # Clean up
            title = re.sub(r'\s*-\s*LinkedIn$', '', title)
            company = re.sub(r'\s*-\s*LinkedIn$', '', company)
            
            if len(title) > 0 and len(company) > 0 and len(title) < 100:
                return title, company
    
    # Fallback: extract from title
    parts = title.split('-')
    if len(parts) >= 2:
        return parts[0].strip(), parts[1].strip()
    
    return title.split('|')[0].strip(), "Unknown Company"


def multi_dork_search(company_name: str, api_key: str, dorks_to_use: int = 60, results_per_dork: int = 5) -> Dict[str, List[Contact]]:
    """
    Search using multiple dorks and organize results
    Returns dict with dork as key and list of contacts as value
    """
    
    print(f"\n{'='*80}")
    print(f" MULTI-DORK SEARCH")
    print(f"{'='*80}")
    print(f"Company: {company_name}")
    print(f"Dorks to use: {dorks_to_use}")
    print(f"Results per dork: {results_per_dork}")
    print()
    
    all_results = {}
    unique_linkedin_urls = set()
    total_found = 0
    total_verified_ex = 0
    
    dorks = [d.format(company=company_name) for d in DORK_TEMPLATES[:dorks_to_use]]
    
    for i, dork in enumerate(dorks, 1):
        print(f"[{i}/{len(dorks)}] Searching with dork...")
        print(f"    Query: {dork[:70]}...")
        
        results = search_with_dork(dork, api_key, results_per_dork)
        
        if not results:
            print(f"    ✗ No results")
            time.sleep(DELAY_BETWEEN_SEARCHES)
            continue
        
        print(f"    ✓ Found {len(results)} results")
        
        dork_contacts = []
        
        for result in results:
            link = result.get('link', '')
            
            # Only LinkedIn profiles
            if 'linkedin.com/in/' not in link:
                continue
            
            # Skip duplicates
            if link in unique_linkedin_urls:
                continue
            
            title = result.get('title', '')
            snippet = result.get('snippet', '')
            
            # CRITICAL: Check if still working
            if is_still_working(snippet, title, company_name):
                print(f"    ⚠️  Skipping (still working): {title[:50]}...")
                continue
            
            # Extract info
            name = title.split(' - ')[0].strip() if ' - ' in title else title.split('|')[0].strip()
            current_title, current_company = extract_current_position(snippet, title)
            position_level = PositionClassifier.classify(current_title)
            
            contact = Contact(
                name=name,
                linkedin_url=link,
                current_company=current_company,
                current_title=current_title,
                previous_company=company_name,
                position_level=position_level,
                snippet=snippet,
                dork_used=dork,
                verified_ex_employee=True
            )
            
            dork_contacts.append(contact)
            unique_linkedin_urls.add(link)
            total_found += 1
            total_verified_ex += 1
        
        if dork_contacts:
            all_results[dork] = dork_contacts
            print(f"    ✓ Added {len(dork_contacts)} verified ex-employees")
        
        time.sleep(DELAY_BETWEEN_SEARCHES)
    
    print(f"\n{'='*80}")
    print(f"SEARCH COMPLETE")
    print(f"{'='*80}")
    print(f"Total unique ex-employees found: {total_verified_ex}")
    print(f"Successful dorks: {len(all_results)}")
    print()
    
    return all_results


def flatten_results(dork_results: Dict[str, List[Contact]]) -> List[Contact]:
    """Flatten dork results into single list"""
    
    all_contacts = []
    for dork, contacts in dork_results.items():
        all_contacts.extend(contacts)
    
    # Remove duplicates by LinkedIn URL
    seen_urls = set()
    unique_contacts = []
    
    for contact in all_contacts:
        if contact.linkedin_url not in seen_urls:
            unique_contacts.append(contact)
            seen_urls.add(contact.linkedin_url)
    
    return unique_contacts


def print_dork_summary(dork_results: Dict[str, List[Contact]]):
    """Print summary of results per dork"""
    
    print(f"\n{'='*80}")
    print(f" RESULTS BY DORK")
    print(f"{'='*80}")
    
    # Sort by number of results
    sorted_dorks = sorted(dork_results.items(), key=lambda x: len(x[1]), reverse=True)
    
    for i, (dork, contacts) in enumerate(sorted_dorks[:20], 1):  # Top 20
        levels = {'CXO': 0, 'SENIOR': 0, 'MANAGER': 0, 'OTHER': 0}
        for c in contacts:
            levels[c.position_level] = levels.get(c.position_level, 0) + 1
        
        print(f"\n{i}. {dork[:70]}...")
        print(f"   Found: {len(contacts)} ex-employees")
        print(f"    CXO: {levels['CXO']} |  Senior: {levels['SENIOR']} |  Manager: {levels['MANAGER']} | ⚪ Other: {levels['OTHER']}")
    
    if len(sorted_dorks) > 20:
        print(f"\n   ... and {len(sorted_dorks) - 20} more dorks")


def print_contact_list(contacts: List[Contact], max_show: int = 50):
    """Print formatted contact list"""
    
    print(f"\n{'='*80}")
    print(f" VERIFIED EX-EMPLOYEES ({len(contacts)} total)")
    print(f"{'='*80}")
    
    # Sort by position level
    level_order = {'CXO': 0, 'SENIOR': 1, 'MANAGER': 2, 'OTHER': 3}
    sorted_contacts = sorted(contacts, key=lambda x: level_order.get(x.position_level, 4))
    
    for i, contact in enumerate(sorted_contacts[:max_show], 1):
        level_emoji = {'CXO': '', 'SENIOR': '', 'MANAGER': '', 'OTHER': '⚪'}
        emoji = level_emoji.get(contact.position_level, '⚪')
        
        print(f"\n{i}. {emoji} {contact.name} ({contact.position_level})")
        print(f"   Previous: {contact.previous_company}")
        print(f"   Current:  {contact.current_title} at {contact.current_company}")
        print(f"   LinkedIn: {contact.linkedin_url}")
        print(f"   Found via: {contact.dork_used[:60]}...")
    
    if len(sorted_contacts) > max_show:
        print(f"\n... and {len(sorted_contacts) - max_show} more contacts")


def save_results(contacts: List[Contact], filename: str):
    """Save to JSON"""
    with open(filename, 'w') as f:
        json.dump([c.to_dict() for c in contacts], f, indent=2)


def main():
    """Main execution"""
    
    print("\n" + "="*80)
    print(" ADVANCED EX-EMPLOYEE FINDER")
    print("="*80)
    print("\nUsing 60 Google dorks to find VERIFIED ex-employees")
    print("(People who have LEFT the company)")
    print()
    
    # Get company name
    company_name = input("Enter company name: ").strip()
    
    if not company_name:
        print("Error: Company name required")
        return
    
    print(f"\n✓ Company: {company_name}")
    print(f"✓ Using {MAX_DORKS_TO_USE} different search strategies")
    print(f"✓ Scraping top {RESULTS_PER_DORK} results per strategy")
    print(f"✓ Filtering out current employees")
    print()
    
    input("Press ENTER to start search...")
    
    # Multi-dork search
    dork_results = multi_dork_search(
        company_name=company_name,
        api_key=SEARCHAPI_KEY,
        dorks_to_use=MAX_DORKS_TO_USE,
        results_per_dork=RESULTS_PER_DORK
    )
    
    if not dork_results:
        print("\n❌ No ex-employees found")
        return
    
    # Print dork summary
    print_dork_summary(dork_results)
    
    # Flatten results
    all_contacts = flatten_results(dork_results)
    
    # Filter by position if needed
    if MIN_POSITION_LEVEL != "OTHER":
        level_order = {'CXO': 0, 'SENIOR': 1, 'MANAGER': 2, 'OTHER': 3}
        min_priority = level_order.get(MIN_POSITION_LEVEL, 3)
        
        filtered = [
            c for c in all_contacts
            if level_order.get(c.position_level, 4) <= min_priority
        ]
        
        print(f"\n Filtered by position ({MIN_POSITION_LEVEL}+): {len(all_contacts)} → {len(filtered)}")
        all_contacts = filtered
    
    # Print contact list
    print_contact_list(all_contacts, max_show=100)
    
    # Position summary
    levels = {'CXO': 0, 'SENIOR': 0, 'MANAGER': 0, 'OTHER': 0}
    for c in all_contacts:
        levels[c.position_level] = levels.get(c.position_level, 0) + 1
    
    print(f"\n{'='*80}")
    print(f" SUMMARY")
    print(f"{'='*80}")
    print(f"Total verified ex-employees: {len(all_contacts)}")
    print()
    print("Position Breakdown:")
    print(f"   CXO:      {levels['CXO']}")
    print(f"   Senior:   {levels['SENIOR']}")
    print(f"   Manager:  {levels['MANAGER']}")
    print(f"  ⚪ Other:    {levels['OTHER']}")
    
    # Save
    save_results(all_contacts, OUTPUT_FILE)
    
    print(f"\n{'='*80}")
    print(f"✅ RESULTS SAVED")
    print(f"{'='*80}")
    print(f"File: {OUTPUT_FILE}")
    print(f"Total contacts: {len(all_contacts)}")
    print()
    
    # Ask if user wants to process with AI
    process = input("\nProcess these contacts with AI? (categorize, profiles, emails) [y/N]: ").strip().lower()
    
    if process == 'y':
        print("\n⚠️  AI processing will be added in next update")
        print("For now, you have the verified ex-employee list in JSON format")
    
    print("\n✅ Complete!")


if __name__ == "__main__":
    main()

