# 🎯 AI Ex-Employee Finder - Frontend UI

A stunning AI-powered chat interface for finding former employees on LinkedIn using advanced Google dork search strategies.

## ✨ Features

- **🤖 AI Chat Assistant** - Natural language interface to specify company names
- **🔐 Frontend API Key Management** - Enter API keys directly in the UI (no backend config needed)
- **🎨 Beautiful Modern Design** - Glassmorphism UI with smooth animations
- **📊 Real-time Progress** - Live search progress with visual feedback
- **💼 Smart Filtering** - Filter by position level (CXO, Senior, Manager, Other)
- **📱 Responsive Design** - Works perfectly on desktop and mobile
- **⚡ Fast & Efficient** - Uses 60 different search strategies simultaneously

## 🚀 Quick Start

### Prerequisites

- Python 3.7+
- Modern web browser
- Anthropic API key (from https://console.anthropic.com/)
- SearchAPI key (from https://www.searchapi.io/)

### Installation

1. **Install Python dependencies:**
```bash
pip install flask flask-cors requests
```

2. **Start the backend server:**
```bash
python backend_server.py
```

You should see:
```
🚀 Starting Flask server...
📡 Frontend should connect to: http://localhost:5000
```

3. **Open the frontend:**
Simply open `index.html` in your web browser (double-click the file or use a local server)

### Usage

1. **Enter API Keys** (in the left panel):
   - Anthropic API Key: `sk-ant-...`
   - SearchAPI Key: Your SearchAPI key

2. **Configure Search Parameters** (optional):
   - Results per Dork: How many results to fetch per search query (3-10)
   - Max Dorks: How many different search strategies to use (10-60)
   - Position Level: Filter results by seniority

3. **Chat with the AI Assistant**:
   - Type: "Former employees of Google"
   - Or simply: "TechDefence"
   - The AI will extract the company name automatically

4. **Start the Search**:
   - Click "🚀 Start Search" button when prompted
   - Watch the real-time progress bar
   - Results will appear below when complete

5. **View Results**:
   - Browse through verified ex-employee profiles
   - Click LinkedIn links to view full profiles
   - Results are color-coded by position level:
     - 🔴 Red = CXO
     - 🟠 Orange = Senior
     - 🟢 Green = Manager
     - ⚪ White = Other

## 📁 File Structure

```
ex-employee-finder/
├── index.html              # Main UI (Frontend)
├── app.js                  # JavaScript logic & API integration
├── backend_server.py       # Flask backend server (connects to your Python code)
├── Improvedcode.py         # Your original backend search logic
└── README.md              # This file
```

## 🔧 How It Works

### Frontend (index.html + app.js)
1. User enters API keys in the UI
2. AI chat extracts company name from natural language
3. Frontend sends request to backend with all configuration
4. Real-time progress updates as search runs
5. Results displayed in beautiful cards

### Backend (backend_server.py)
1. Receives search request from frontend
2. Uses your existing `Improvedcode.py` logic
3. Executes 60 different Google dork searches
4. Filters out current employees (keeps only ex-employees)
5. Returns verified results to frontend

### Your Original Code (Improvedcode.py)
- All the sophisticated search logic remains **100% unchanged**
- Same dork templates
- Same verification algorithms
- Same classification system

## 🎨 UI Features

### Chat Interface
- Natural language processing to extract company names
- Example inputs:
  - "Former employees of Google"
  - "Ex-employees at Microsoft"  
  - Just "Apple"
- Smart company name extraction with multiple pattern matching

### Configuration Panel
- **API Keys**: Secure input fields (password-masked)
- **Search Settings**: Customize results per dork and max dorks
- **Position Filters**: CXO, Senior, Manager, or All Levels
- **Sticky Panel**: Stays visible while scrolling

### Progress Tracking
- Real-time progress bar
- Dork counter (e.g., "35 / 60 dorks")
- Status messages during search
- Smooth animations

### Results Display
- Color-coded position badges
- LinkedIn profile links
- Previous and current company info
- Responsive grid layout
- Hover effects and smooth transitions

## 🔐 API Keys

### Where to Get Them:

1. **Anthropic API Key**
   - Go to: https://console.anthropic.com/
   - Sign up / Log in
   - Create a new API key
   - Format: `sk-ant-api03-...`

2. **SearchAPI Key**
   - Go to: https://www.searchapi.io/
   - Sign up / Log in
   - Get your API key from dashboard
   - Free tier includes 100 searches/month

### Security Notes:
- API keys are entered in the frontend (not stored in files)
- Never commit API keys to version control
- Keys are sent to backend via POST request only
- Backend doesn't store keys permanently

## 🎯 Example Searches

Try these in the chat:

```
"Former employees of Google"
"Ex-employees at Amazon"
"People who left Facebook"
"TechDefence"
"Anthropic"
```

The AI will automatically extract the company name!

## 📊 Sample Output

```
Search Complete!
Found 47 verified ex-employees of Google.

Position Breakdown:
  🔴 CXO:      5
  🟠 Senior:   18
  🟢 Manager:  15
  ⚪ Other:    9
```

## 🐛 Troubleshooting

### Backend not starting?
```bash
# Install required packages
pip install flask flask-cors requests

# Check if port 5000 is available
# On Mac/Linux:
lsof -i :5000

# On Windows:
netstat -ano | findstr :5000
```

### Frontend can't connect to backend?
1. Make sure backend is running (you should see Flask server messages)
2. Check console for CORS errors
3. Verify URL is `http://localhost:5000`

### No results found?
1. Verify API keys are correct
2. Try the company's full legal name
3. Check if company exists on LinkedIn
4. Reduce position filter (try "All Levels")

### Search is slow?
1. Reduce "Results per Dork" (try 3 instead of 5)
2. Reduce "Max Dorks" (try 20 instead of 60)
3. This is normal for comprehensive searches (be patient!)

## 🚀 Advanced Features

### Customization

**Change color scheme** (in index.html):
```css
:root {
    --accent: #06b6d4;        /* Change main color */
    --accent-bright: #22d3ee;  /* Change bright accent */
}
```

**Add more dorks** (in backend_server.py):
```python
DORK_TEMPLATES.append('site:linkedin.com/in "your custom dork"')
```

### Export Results

Add a download button (in app.js):
```javascript
function downloadResults() {
    const dataStr = JSON.stringify(state.results, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `results_${state.companyName}.json`;
    link.click();
}
```

## 📝 Technical Details

### Technologies Used

**Frontend:**
- HTML5
- CSS3 (Glassmorphism design)
- Vanilla JavaScript (no frameworks!)
- Google Fonts (Archivo, IBM Plex Mono)

**Backend:**
- Python 3.7+
- Flask (web framework)
- Flask-CORS (cross-origin support)
- Requests (HTTP client)

### Architecture

```
Browser (Frontend)
    ↓
  index.html + app.js
    ↓
  HTTP POST /api/search
    ↓
backend_server.py (Flask)
    ↓
Your existing Improvedcode.py logic
    ↓
SearchAPI (Google Search)
    ↓
LinkedIn Results
    ↓
Filtered & Verified Results
    ↓
Return to Frontend
    ↓
Display in Beautiful UI
```

## 🎓 Learning Resources

- [Flask Documentation](https://flask.palletsprojects.com/)
- [Fetch API](https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API)
- [CSS Glassmorphism](https://css.glass/)
- [Google Dorks Guide](https://www.exploit-db.com/google-hacking-database)

## 📄 License

This project integrates with your existing backend code. Make sure to comply with:
- LinkedIn's Terms of Service
- SearchAPI's Terms of Use
- Anthropic's API Terms

## 🤝 Support

For issues or questions:
1. Check the Troubleshooting section above
2. Review console logs (F12 in browser)
3. Check Flask server terminal output
4. Verify API keys are valid

## 🎉 Credits

- Original backend logic: Your `Improvedcode.py`
- UI Design: Custom glassmorphism interface
- Font: Archivo & IBM Plex Mono (Google Fonts)

---

**Made with ❤️ for efficient LinkedIn research**

🔍 Happy searching! 🎯
