#!/usr/bin/env python3
"""
Lead Research Orchestrator - Pure Google Dorking Method
NO AI - Direct Google dork queries with company name replacement
Search limit: 100 results
"""

import os
import re
import time
from datetime import datetime
from flask import Flask, render_template, request, jsonify, send_file
import pandas as pd
import requests
from bs4 import BeautifulSoup
from typing import List, Dict
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(message)s')
logger = logging.getLogger(__name__)

app = Flask(__name__)

OUTPUT_DIR = '/home/claude/lead-research-tool/outputs'
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Google Dork Templates - {company} will be replaced with actual company name
GOOGLE_DORK_TEMPLATES = [
    'site:linkedin.com/in/ "{company}" "CTO" OR "Chief Technology Officer"',
    'site:linkedin.com/in/ "{company}" "CEO" OR "Chief Executive Officer"',
    'site:linkedin.com/in/ "{company}" "CFO" OR "Chief Financial Officer"',
    'site:linkedin.com/in/ "{company}" "COO" OR "Chief Operating Officer"',
    'site:linkedin.com/in/ "{company}" "VP" OR "Vice President"',
    'site:linkedin.com/in/ "{company}" "Director"',
    'site:linkedin.com/in/ "{company}" "Manager"',
    'site:linkedin.com/in/ "{company}" "Head of"',
    'site:linkedin.com/in/ "former" "{company}" "joined" OR "now at"',
    'site:linkedin.com/in/ "ex-{company}" OR "former {company}"',
    'site:linkedin.com/in/ "{company}" "left" OR "moved to"',
    'site:linkedin.com/in/ "{company}" "previously" OR "past"',
]

class GoogleDorkSearcher:
    """Pure Google Dorking - No AI, No APIs"""
    
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'DNT': '1',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'
        })
        
    def search_duckduckgo(self, query: str, max_results: int = 100) -> List[Dict]:
        """Search DuckDuckGo with Google dorks"""
        results = []
        logger.info(f"🔍 Searching: {query}")
        
        try:
            url = "https://html.duckduckgo.com/html/"
            
            # Make multiple requests to get more results
            pages_needed = (max_results // 30) + 1  # ~30 results per page
            
            for page in range(pages_needed):
                data = {
                    'q': query,
                    'b': '',  # Start parameter
                    's': str(page * 30)  # Offset
                }
                
                response = self.session.post(url, data=data, timeout=20)
                response.raise_for_status()
                
                soup = BeautifulSoup(response.text, 'html.parser')
                
                for result in soup.find_all('div', class_='result'):
                    if len(results) >= max_results:
                        break
                        
                    title_elem = result.find('a', class_='result__a')
                    snippet_elem = result.find('a', class_='result__snippet')
                    
                    if title_elem and 'linkedin.com/in/' in title_elem.get('href', ''):
                        results.append({
                            'title': title_elem.get_text(strip=True),
                            'url': title_elem.get('href', ''),
                            'snippet': snippet_elem.get_text(strip=True) if snippet_elem else '',
                            'source': 'DuckDuckGo'
                        })
                
                if len(results) >= max_results:
                    break
                    
                # Rate limiting
                time.sleep(2)
            
            logger.info(f"✓ Found {len(results)} results")
            return results[:max_results]
            
        except Exception as e:
            logger.error(f"Search error: {e}")
            return results
    
    def extract_profile_data(self, result: Dict, company: str) -> Dict:
        """Extract profile information from search result"""
        title = result.get('title', '')
        snippet = result.get('snippet', '')
        url = result.get('url', '')
        
        # Extract name (first part of title before dash or pipe)
        name = 'Unknown'
        name_match = re.match(r'^([^-|]+)', title)
        if name_match:
            name = name_match.group(1).strip()
            # Remove LinkedIn suffix
            name = re.sub(r'\s*-?\s*LinkedIn.*$', '', name, flags=re.IGNORECASE).strip()
        
        # Extract current company
        current_company = 'Unknown'
        current_role = 'Unknown'
        
        text = f"{title} {snippet}"
        
        # Try to find current company
        company_patterns = [
            r'(?:at|@)\s+([A-Z][A-Za-z0-9\s&.,-]+?)(?:\s+[-|•·]|\s*$)',
            r'(?:current|now)(?:\s+at)?\s+([A-Z][A-Za-z0-9\s&.,-]+)',
        ]
        
        for pattern in company_patterns:
            match = re.search(pattern, text)
            if match:
                found = match.group(1).strip()
                if found.lower() not in ['linkedin', 'profile', 'view']:
                    current_company = found[:60]
                    break
        
        # Extract role
        role_patterns = [
            r'(CEO|CTO|CFO|COO|Chief\s+\w+\s+Officer)',
            r'(VP|Vice\s+President|SVP|EVP)(?:\s+of\s+\w+)?',
            r'(Director|Senior\s+Director|Head\s+of\s+\w+)',
            r'(Manager|Senior\s+Manager|Lead)',
        ]
        
        for pattern in role_patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                current_role = match.group(0)
                break
        
        # Generate email
        email = self._generate_email(name, current_company)
        
        return {
            'name': name,
            'previous_company': company,
            'previous_role': 'Unknown',
            'current_company': current_company,
            'current_role': current_role,
            'linkedin_url': url,
            'estimated_email': email,
            'email_confidence': 'Medium',
            'phone': 'Not Found',
            'source': 'Google Dork',
            'snippet': snippet[:200],
            'last_updated': datetime.now().isoformat()
        }
    
    def _generate_email(self, name: str, company: str) -> str:
        """Generate email using pattern matching"""
        try:
            parts = name.lower().split()
            first = parts[0] if parts else 'unknown'
            last = parts[-1] if len(parts) > 1 else 'user'
            
            # Clean company name for domain
            domain = company.lower()
            domain = re.sub(r'\s+(inc|llc|ltd|corp|limited|corporation)\.?$', '', domain)
            domain = re.sub(r'[^a-z0-9]', '', domain)
            
            if len(domain) > 15:
                domain = company.split()[0].lower()
                domain = re.sub(r'[^a-z0-9]', '', domain)
            
            return f"{first}.{last}@{domain}.com"
        except:
            return "unknown@unknown.com"


class LeadResearcher:
    """Main lead research orchestrator"""
    
    def __init__(self):
        self.searcher = GoogleDorkSearcher()
        
    def research(self, company: str, max_results: int = 100) -> Dict:
        """Research leads for a company using Google dorks"""
        
        logger.info("=" * 80)
        logger.info(f"🎯 STARTING RESEARCH FOR: {company}")
        logger.info(f"📊 Target Results: {max_results}")
        logger.info("=" * 80)
        
        all_profiles = []
        seen_urls = set()
        
        # Execute each Google dork template
        for template in GOOGLE_DORK_TEMPLATES:
            query = template.replace('{company}', company)
            
            # Calculate how many results we still need
            remaining = max_results - len(all_profiles)
            if remaining <= 0:
                break
            
            # Search with this dork
            results = self.searcher.search_duckduckgo(query, max_results=remaining)
            
            # Process results
            for result in results:
                url = result['url']
                
                # Skip duplicates
                if url in seen_urls:
                    continue
                    
                seen_urls.add(url)
                
                # Extract profile data
                profile = self.searcher.extract_profile_data(result, company)
                all_profiles.append(profile)
                
                logger.info(f"  ✓ {len(all_profiles)}/{max_results} - {profile['name']}")
                
                if len(all_profiles) >= max_results:
                    break
            
            # Rate limiting between queries
            time.sleep(3)
            
            if len(all_profiles) >= max_results:
                break
        
        logger.info("=" * 80)
        logger.info(f"✅ COMPLETED: Found {len(all_profiles)} profiles")
        logger.info("=" * 80)
        
        return {
            'company': company,
            'max_results': max_results,
            'leads_found': all_profiles,
            'dork_queries_used': [t.replace('{company}', company) for t in GOOGLE_DORK_TEMPLATES],
            'timestamp': datetime.now().isoformat()
        }


# Initialize
researcher = LeadResearcher()

@app.route('/')
def index():
    """Main UI page"""
    return render_template('index_simple.html')

@app.route('/api/research', methods=['POST'])
def research_leads():
    """API endpoint for lead research"""
    try:
        data = request.json
        company = data.get('company', '').strip()
        max_results = int(data.get('max_results', 100))
        
        if not company:
            return jsonify({'error': 'Company name is required'}), 400
        
        if max_results < 1 or max_results > 200:
            return jsonify({'error': 'Max results must be between 1 and 200'}), 400
        
        # Conduct research
        results = researcher.research(company, max_results)
        
        # Save to Excel
        if results['leads_found']:
            excel_path = save_to_excel(results)
            results['excel_file'] = os.path.basename(excel_path)
        
        return jsonify({
            'success': True,
            'results': results,
            'total_leads': len(results['leads_found'])
        })
        
    except Exception as e:
        logger.error(f"Error: {str(e)}", exc_info=True)
        return jsonify({'error': str(e)}), 500

@app.route('/api/download/<filename>')
def download_file(filename):
    """Download generated Excel file"""
    file_path = os.path.join(OUTPUT_DIR, filename)
    if os.path.exists(file_path):
        return send_file(file_path, as_attachment=True)
    return jsonify({'error': 'File not found'}), 404

def save_to_excel(results):
    """Save results to Excel file"""
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    company_safe = re.sub(r'[^a-zA-Z0-9]', '_', results['company'])
    filename = f'leads_{company_safe}_{timestamp}.xlsx'
    filepath = os.path.join(OUTPUT_DIR, filename)
    
    # Convert leads to DataFrame
    df = pd.DataFrame(results['leads_found'])
    
    # Create Excel writer
    with pd.ExcelWriter(filepath, engine='openpyxl') as writer:
        # Main leads sheet
        df.to_excel(writer, sheet_name='Leads', index=False)
        
        # Research info sheet
        info_df = pd.DataFrame([{
            'Company': results['company'],
            'Max Results': results['max_results'],
            'Actual Results': len(results['leads_found']),
            'Timestamp': results['timestamp']
        }])
        info_df.to_excel(writer, sheet_name='Research Info', index=False)
        
        # Google dorks used
        dorks_df = pd.DataFrame({'Google Dorks Used': results['dork_queries_used']})
        dorks_df.to_excel(writer, sheet_name='Dork Queries', index=False)
    
    logger.info(f"✅ Excel saved: {filepath}")
    return filepath

if __name__ == '__main__':
    print("\n" + "=" * 80)
    print("🚀 LEAD RESEARCH ORCHESTRATOR - PURE GOOGLE DORKING")
    print("=" * 80)
    print("✓ NO AI - Direct company name substitution")
    print("✓ NO APIs - Pure DuckDuckGo scraping")
    print("✓ 100 Results Limit - Configurable")
    print("✓ 12 Google Dork Templates")
    print("=" * 80)
    print("📁 Output Directory:", OUTPUT_DIR)
    print("🌐 Starting server on http://localhost:5000")
    print("=" * 80 + "\n")
    
    app.run(host='0.0.0.0', port=5000, debug=True, use_reloader=False)
