#!/usr/bin/env python3
"""
CLI tool for Ex-Employee LinkedIn Outreach
Usage: python enhanced_cli.py --company "Decimal Point Analytics" --output results.json
"""

import argparse
import os
import sys
from enhanced_sales_agent import EnhancedSalesAgent
import json


def main():
    parser = argparse.ArgumentParser(
        description='Find and process ex-employees for outreach',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Basic search
  python enhanced_cli.py --company "Decimal Point Analytics"
  
  # With custom output
  python enhanced_cli.py --company "Acme Corp" --output acme_ex_employees.json
  
  # Limit results
  python enhanced_cli.py --company "Tech Inc" --max 50
  
  # Search only (no processing)
  python enhanced_cli.py --company "BigCo" --search-only
  
  # Filter by position level
  python enhanced_cli.py --company "StartupXYZ" --min-level SENIOR
        """
    )
    
    # Required arguments
    parser.add_argument(
        '--company',
        required=True,
        help='Company name to search for ex-employees'
    )
    
    # API keys
    parser.add_argument(
        '--anthropic-key',
        help='Anthropic API key (or set ANTHROPIC_API_KEY env var)'
    )
    
    parser.add_argument(
        '--searchapi-key',
        help='SearchAPI key (or set SEARCHAPI_KEY env var)'
    )
    
    # Optional arguments
    parser.add_argument(
        '--max',
        type=int,
        default=50,
        help='Maximum number of results (default: 50)'
    )
    
    parser.add_argument(
        '--output',
        default='ex_employees.json',
        help='Output file path (default: ex_employees.json)'
    )
    
    parser.add_argument(
        '--search-only',
        action='store_true',
        help='Only search, do not process (categorize/profile/email)'
    )
    
    parser.add_argument(
        '--min-level',
        choices=['CXO', 'SENIOR', 'MANAGER', 'OTHER'],
        help='Minimum position level to process'
    )
    
    parser.add_argument(
        '--config',
        help='Path to config JSON file (company context, services)'
    )
    
    args = parser.parse_args()
    
    # Get API keys
    anthropic_key = args.anthropic_key or os.getenv('ANTHROPIC_API_KEY')
    searchapi_key = args.searchapi_key or os.getenv('SEARCHAPI_KEY')
    
    if not anthropic_key or not searchapi_key:
        print("Error: API keys required")
        print("Provide via --anthropic-key and --searchapi-key")
        print("Or set ANTHROPIC_API_KEY and SEARCHAPI_KEY environment variables")
        sys.exit(1)
    
    # Initialize agent
    print(f"🤖 Initializing agent...")
    agent = EnhancedSalesAgent(
        anthropic_api_key=anthropic_key,
        searchapi_key=searchapi_key
    )
    
    # Search for ex-employees
    print(f"\n🔍 Searching for ex-employees of {args.company}...")
    contacts, stats = agent.find_ex_employees(
        company_name=args.company,
        max_results=args.max
    )
    
    if not contacts:
        print("❌ No ex-employees found")
        sys.exit(0)
    
    # Filter by position level if specified
    if args.min_level:
        level_order = {'CXO': 0, 'SENIOR': 1, 'MANAGER': 2, 'OTHER': 3}
        min_priority = level_order[args.min_level]
        
        filtered_contacts = [
            c for c in contacts 
            if level_order.get(c.position_level, 4) <= min_priority
        ]
        
        print(f"\n🎯 Filtered to {len(filtered_contacts)} contacts (>= {args.min_level} level)")
        contacts = filtered_contacts
    
    # Save search results
    search_output = args.output.replace('.json', '_search.json')
    with open(search_output, 'w') as f:
        json.dump([c.to_dict() for c in contacts], f, indent=2)
    print(f"💾 Search results saved to {search_output}")
    
    # Process if not search-only
    if not args.search_only:
        # Load config
        if args.config:
            print(f"\n📋 Loading config from {args.config}...")
            with open(args.config, 'r') as f:
                config = json.load(f)
        else:
            # Default config
            config = {
                'company_context': 'We are a digital transformation consultancy.',
                'our_services': 'AI/ML, Cloud, Data Analytics, Automation',
                'campaign_goal': 'schedule discovery call'
            }
        
        print(f"\n🚀 Processing {len(contacts)} contacts...")
        
        processed_contacts, final_stats = agent.process_ex_employees(
            company_name=args.company,
            company_context=config['company_context'],
            our_services=config['our_services'],
            max_results=args.max,
            campaign_goal=config.get('campaign_goal', 'schedule discovery call'),
            output_file=args.output
        )
        
        print(f"\n✅ Complete! Results saved to {args.output}")
        
        # Show high-value contacts
        high_value = [
            c for c in processed_contacts 
            if c.position_level in ['CXO', 'SENIOR'] 
            and c.category in ['A', 'B', 'C']
        ]
        
        if high_value:
            print(f"\n⭐ TOP HIGH-VALUE CONTACTS ({len(high_value)}):")
            print("="*70)
            for i, c in enumerate(high_value[:10], 1):
                print(f"{i}. {c.name}")
                print(f"   {c.current_title} at {c.current_company}")
                print(f"   Level: {c.position_level} | Category: {c.category}")
                print()


if __name__ == '__main__':
    main()
