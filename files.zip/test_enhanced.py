"""
Test script for Enhanced LinkedIn Search Agent
Tests SearchAPI integration and position classification
"""

import os
from enhanced_sales_agent import EnhancedSalesAgent, PositionAnalyzer


def test_position_classifier():
    """Test position classification logic"""
    
    print("🧪 Testing Position Classifier")
    print("="*60)
    
    test_titles = [
        ("Chief Executive Officer", "CXO"),
        ("CEO & Founder", "CXO"),
        ("Chief Technology Officer", "CXO"),
        ("President", "CXO"),
        ("Vice President of Engineering", "SENIOR"),
        ("VP Sales", "SENIOR"),
        ("Director of Data Science", "SENIOR"),
        ("Head of Product", "SENIOR"),
        ("Senior Manager", "MANAGER"),
        ("Engineering Manager", "MANAGER"),
        ("Team Lead", "MANAGER"),
        ("Senior Software Engineer", "OTHER"),
        ("Data Analyst", "OTHER"),
    ]
    
    passed = 0
    failed = 0
    
    for title, expected in test_titles:
        result = PositionAnalyzer.classify_position(title)
        status = "✓" if result == expected else "✗"
        
        if result == expected:
            passed += 1
        else:
            failed += 1
            
        print(f"{status} '{title}' → {result} (expected: {expected})")
    
    print()
    print(f"Results: {passed} passed, {failed} failed")
    print()


def test_linkedin_search():
    """Test LinkedIn search via SearchAPI"""
    
    print("🔍 Testing LinkedIn Search")
    print("="*60)
    
    # Check for API keys
    anthropic_key = os.getenv('ANTHROPIC_API_KEY')
    searchapi_key = os.getenv('SEARCHAPI_KEY')
    
    if not anthropic_key or not searchapi_key:
        print("⚠️  Skipping search test - API keys not found")
        print("   Set ANTHROPIC_API_KEY and SEARCHAPI_KEY to run this test")
        return
    
    # Initialize agent
    print("Initializing agent...")
    agent = EnhancedSalesAgent(
        anthropic_api_key=anthropic_key,
        searchapi_key=searchapi_key
    )
    
    # Test search
    print("\nSearching for ex-employees of 'Google' (limited to 10 results)...")
    contacts, stats = agent.find_ex_employees(
        company_name="Google",
        max_results=10
    )
    
    if contacts:
        print(f"\n✓ Search successful!")
        print(f"  Found: {len(contacts)} contacts")
        print(f"  CXO: {stats['by_level']['CXO']}")
        print(f"  Senior: {stats['by_level']['SENIOR']}")
        print(f"  Manager: {stats['by_level']['MANAGER']}")
        print(f"  Other: {stats['by_level']['OTHER']}")
        
        # Show sample
        print("\nSample contacts:")
        for i, contact in enumerate(contacts[:3], 1):
            print(f"\n{i}. {contact.name}")
            print(f"   Level: {contact.position_level}")
            print(f"   Current: {contact.current_title} at {contact.current_company}")
            print(f"   LinkedIn: {contact.linkedin_url}")
    else:
        print("✗ No contacts found")
    
    print()


def test_full_pipeline():
    """Test complete processing pipeline"""
    
    print("🚀 Testing Full Pipeline")
    print("="*60)
    
    # Check for API keys
    anthropic_key = os.getenv('ANTHROPIC_API_KEY')
    searchapi_key = os.getenv('SEARCHAPI_KEY')
    
    if not anthropic_key or not searchapi_key:
        print("⚠️  Skipping pipeline test - API keys not found")
        return
    
    # Initialize
    agent = EnhancedSalesAgent(
        anthropic_api_key=anthropic_key,
        searchapi_key=searchapi_key
    )
    
    # Config
    company_context = "We are a tech consultancy specializing in cloud and AI."
    our_services = "Cloud migration, AI implementation, data analytics"
    
    print("Processing 5 ex-employees of 'Microsoft'...")
    
    try:
        contacts, stats = agent.process_ex_employees(
            company_name="Microsoft",
            company_context=company_context,
            our_services=our_services,
            max_results=5,
            output_file="test_results.json"
        )
        
        print(f"\n✓ Pipeline test successful!")
        print(f"  Processed: {len(contacts)} contacts")
        print(f"  Emails generated: {stats.get('emails_generated', 0)}")
        print(f"  Results saved to: test_results.json")
        
        # Show one email
        email_contacts = [c for c in contacts if c.custom_email]
        if email_contacts:
            sample = email_contacts[0]
            print(f"\nSample email for {sample.name}:")
            print("-"*60)
            print(sample.custom_email[:200] + "...")
            print("-"*60)
        
    except Exception as e:
        print(f"✗ Pipeline test failed: {e}")
    
    print()


def main():
    """Run all tests"""
    
    print("\n" + "="*60)
    print("ENHANCED SALES AGENT TEST SUITE")
    print("="*60 + "\n")
    
    # Test 1: Position Classifier (no API needed)
    test_position_classifier()
    
    # Test 2: LinkedIn Search (requires SearchAPI key)
    test_linkedin_search()
    
    # Test 3: Full Pipeline (requires both API keys)
    test_full_pipeline()
    
    print("="*60)
    print("Testing complete!")
    print("="*60)
    print()
    print("To run all tests, set environment variables:")
    print("  export ANTHROPIC_API_KEY='your-key'")
    print("  export SEARCHAPI_KEY='your-searchapi-key'")
    print()


if __name__ == '__main__':
    main()
