"""
Enhanced Network-Based Sales AI Agent with LinkedIn Search Integration
Tracks ex-employees and prioritizes by current position
"""

import json
import os
import re
import requests
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass, asdict
from datetime import datetime
import anthropic
import time


@dataclass
class Contact:
    """Represents a contact from LinkedIn search"""
    name: str
    linkedin_url: str
    current_company: str
    current_title: str
    previous_company: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    category: Optional[str] = None  # A, B, C, or D
    position_level: Optional[str] = None  # CXO, SENIOR, MANAGER, OTHER
    profile_summary: Optional[str] = None
    custom_email: Optional[str] = None
    approach_plan: Optional[str] = None
    search_snippet: Optional[str] = None
    
    def to_dict(self):
        return asdict(self)


class LinkedInSearcher:
    """
    Handles LinkedIn search via SearchAPI to find ex-employees
    """
    
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.base_url = "https://www.searchapi.io/api/v1/search"
        
    def search_ex_employees(
        self, 
        company_name: str, 
        max_results: int = 100
    ) -> List[Dict]:
        """
        Search for former employees of a company on LinkedIn
        
        Args:
            company_name: Name of the company to search for ex-employees
            max_results: Maximum number of results to return
            
        Returns:
            List of search results with LinkedIn profiles
        """
        
        query = f'Former {company_name} Employee LinkedIn'
        
        params = {
            "engine": "google_light",
            "q": query,
            "api_key": self.api_key,
            "num": min(max_results, 100)  # API limit
        }
        
        print(f"🔍 Searching: {query}")
        
        try:
            response = requests.get(self.base_url, params=params)
            response.raise_for_status()
            data = response.json()
            
            results = data.get('organic_results', [])
            print(f"✓ Found {len(results)} results")
            
            return results
            
        except Exception as e:
            print(f"✗ Search error: {e}")
            return []
    
    def extract_linkedin_profiles(self, search_results: List[Dict]) -> List[Dict]:
        """
        Extract LinkedIn profile information from search results
        
        Args:
            search_results: Raw search results from SearchAPI
            
        Returns:
            List of parsed LinkedIn profiles
        """
        
        profiles = []
        
        for result in search_results:
            link = result.get('link', '')
            
            # Filter for LinkedIn profile URLs
            if 'linkedin.com/in/' in link:
                profile = {
                    'name': self._extract_name(result),
                    'linkedin_url': link,
                    'title': result.get('title', ''),
                    'snippet': result.get('snippet', ''),
                    'description': result.get('description', '')
                }
                
                profiles.append(profile)
        
        print(f"✓ Extracted {len(profiles)} LinkedIn profiles")
        return profiles
    
    def _extract_name(self, result: Dict) -> str:
        """Extract person's name from search result"""
        title = result.get('title', '')
        
        # LinkedIn titles usually format as "Name - Title - LinkedIn"
        if ' - ' in title:
            name = title.split(' - ')[0].strip()
            return name
        
        return title.split('|')[0].strip() if '|' in title else title


class PositionAnalyzer:
    """
    Analyzes job titles to determine seniority level
    """
    
    # Position classification keywords
    CXO_KEYWORDS = [
        'ceo', 'chief executive', 'president', 'founder', 'co-founder',
        'cto', 'chief technology', 'chief technical',
        'cfo', 'chief financial',
        'coo', 'chief operating',
        'cmo', 'chief marketing',
        'ciso', 'chief information security',
        'cio', 'chief information',
        'cdo', 'chief data', 'chief digital',
        'cpo', 'chief product',
        'managing director', 'general manager'
    ]
    
    SENIOR_KEYWORDS = [
        'vp', 'vice president', 'svp', 'senior vice president', 'evp',
        'director', 'head of', 'global head', 'regional head',
        'senior director', 'executive director',
        'partner', 'principal', 'senior partner',
        'lead', 'senior lead', 'staff engineer', 'distinguished'
    ]
    
    MANAGER_KEYWORDS = [
        'manager', 'senior manager', 'team lead', 'project manager',
        'program manager', 'product manager', 'engineering manager'
    ]
    
    @staticmethod
    def classify_position(title: str) -> str:
        """
        Classify position level based on title
        
        Args:
            title: Job title
            
        Returns:
            Position level: CXO, SENIOR, MANAGER, or OTHER
        """
        
        title_lower = title.lower()
        
        # Check CXO level
        for keyword in PositionAnalyzer.CXO_KEYWORDS:
            if keyword in title_lower:
                return 'CXO'
        
        # Check Senior level
        for keyword in PositionAnalyzer.SENIOR_KEYWORDS:
            if keyword in title_lower:
                return 'SENIOR'
        
        # Check Manager level
        for keyword in PositionAnalyzer.MANAGER_KEYWORDS:
            if keyword in title_lower:
                return 'MANAGER'
        
        return 'OTHER'
    
    @staticmethod
    def is_high_value_position(position_level: str) -> bool:
        """Check if position is high value (CXO or SENIOR)"""
        return position_level in ['CXO', 'SENIOR']


class EnhancedSalesAgent:
    """
    Enhanced AI Agent with LinkedIn Search Integration
    """
    
    def __init__(
        self, 
        anthropic_api_key: str, 
        searchapi_key: str,
        crm_history_path: Optional[str] = None
    ):
        """
        Initialize the Enhanced Sales Agent
        
        Args:
            anthropic_api_key: Anthropic API key for Claude
            searchapi_key: SearchAPI key for LinkedIn search
            crm_history_path: Path to JSON file containing historical CRM data
        """
        self.claude = anthropic.Anthropic(api_key=anthropic_api_key)
        self.searcher = LinkedInSearcher(api_key=searchapi_key)
        self.model = "claude-sonnet-4-20250514"
        self.crm_history = self._load_crm_history(crm_history_path) if crm_history_path else {}
        
    def _load_crm_history(self, path: str) -> Dict:
        """Load historical CRM data"""
        try:
            with open(path, 'r') as f:
                return json.load(f)
        except Exception as e:
            print(f"Warning: Could not load CRM history: {e}")
            return {}
    
    def find_ex_employees(
        self, 
        company_name: str,
        max_results: int = 100,
        prioritize_senior: bool = True
    ) -> Tuple[List[Contact], Dict]:
        """
        Find and categorize ex-employees of a company
        
        Args:
            company_name: Name of the company to search for ex-employees
            max_results: Maximum number of results
            prioritize_senior: Whether to prioritize senior positions
            
        Returns:
            Tuple of (contacts_list, summary_stats)
        """
        
        print(f"\n{'='*70}")
        print(f"FINDING EX-EMPLOYEES: {company_name}")
        print(f"{'='*70}\n")
        
        # Step 1: Search LinkedIn
        search_results = self.searcher.search_ex_employees(company_name, max_results)
        
        if not search_results:
            print("No results found")
            return [], {}
        
        # Step 2: Extract profiles
        profiles = self.searcher.extract_linkedin_profiles(search_results)
        
        # Step 3: Parse and categorize
        contacts = []
        
        for profile in profiles:
            contact = self._parse_linkedin_profile(profile, company_name)
            contacts.append(contact)
        
        # Step 4: Sort by priority (CXO > SENIOR > MANAGER > OTHER)
        if prioritize_senior:
            position_priority = {'CXO': 0, 'SENIOR': 1, 'MANAGER': 2, 'OTHER': 3}
            contacts.sort(key=lambda x: position_priority.get(x.position_level, 4))
        
        # Step 5: Generate summary statistics
        stats = self._generate_stats(contacts)
        
        self._print_summary(stats, company_name)
        
        return contacts, stats
    
    def _parse_linkedin_profile(self, profile: Dict, previous_company: str) -> Contact:
        """
        Parse LinkedIn profile from search result
        
        Args:
            profile: LinkedIn profile data
            previous_company: Company they left
            
        Returns:
            Contact object
        """
        
        # Extract current position and company from snippet/title
        snippet = profile.get('snippet', '')
        title_text = profile.get('title', '')
        
        current_title, current_company = self._extract_current_position(
            snippet, 
            title_text
        )
        
        # Classify position level
        position_level = PositionAnalyzer.classify_position(current_title)
        
        contact = Contact(
            name=profile['name'],
            linkedin_url=profile['linkedin_url'],
            current_company=current_company,
            current_title=current_title,
            previous_company=previous_company,
            position_level=position_level,
            search_snippet=snippet
        )
        
        return contact
    
    def _extract_current_position(self, snippet: str, title: str) -> Tuple[str, str]:
        """
        Extract current title and company from LinkedIn snippet
        
        Args:
            snippet: LinkedIn profile snippet
            title: Page title
            
        Returns:
            Tuple of (current_title, current_company)
        """
        
        # Common patterns in LinkedIn snippets
        # "Title at Company"
        # "Title | Company"
        # "Title - Company"
        
        text = f"{title} {snippet}"
        
        # Try pattern: "Title at Company"
        at_match = re.search(r'([^-|]+?)\s+at\s+([^-|•·]+?)(?:\s*[-|•·]|$)', text, re.IGNORECASE)
        if at_match:
            return at_match.group(1).strip(), at_match.group(2).strip()
        
        # Try pattern: "Title | Company"
        pipe_match = re.search(r'([^-|]+?)\s*\|\s*([^-|•·]+)', text)
        if pipe_match:
            return pipe_match.group(1).strip(), pipe_match.group(2).strip()
        
        # Try pattern: "Title - Company"
        dash_match = re.search(r'([^-]+?)\s*-\s*([^-•·]+?)(?:\s*[-•·]|$)', text)
        if dash_match and len(dash_match.group(1)) < 100:
            return dash_match.group(1).strip(), dash_match.group(2).strip()
        
        # Default: return title and "Unknown"
        return title.split('-')[0].strip(), "Unknown Company"
    
    def _generate_stats(self, contacts: List[Contact]) -> Dict:
        """Generate summary statistics"""
        
        stats = {
            'total': len(contacts),
            'by_level': {'CXO': 0, 'SENIOR': 0, 'MANAGER': 0, 'OTHER': 0},
            'high_value': 0,
            'companies': set()
        }
        
        for contact in contacts:
            level = contact.position_level or 'OTHER'
            stats['by_level'][level] += 1
            
            if PositionAnalyzer.is_high_value_position(level):
                stats['high_value'] += 1
            
            if contact.current_company:
                stats['companies'].add(contact.current_company)
        
        stats['unique_companies'] = len(stats['companies'])
        stats['companies'] = list(stats['companies'])
        
        return stats
    
    def _print_summary(self, stats: Dict, company_name: str):
        """Print search summary"""
        
        print(f"\n{'='*70}")
        print(f"SEARCH SUMMARY: {company_name}")
        print(f"{'='*70}")
        print(f"Total Contacts Found: {stats['total']}")
        print(f"\nBy Position Level:")
        print(f"  🔴 CXO Level:      {stats['by_level']['CXO']:3d}")
        print(f"  🟠 Senior Level:   {stats['by_level']['SENIOR']:3d}")
        print(f"  🟡 Manager Level:  {stats['by_level']['MANAGER']:3d}")
        print(f"  ⚪ Other:          {stats['by_level']['OTHER']:3d}")
        print(f"\n⭐ High Value (CXO + Senior): {stats['high_value']}")
        print(f"🏢 Unique Companies: {stats['unique_companies']}")
        print(f"{'='*70}\n")
    
    def categorize_contact(self, contact: Contact, company_context: str = "") -> str:
        """
        Categorize contact (same as original)
        Enhanced with position level consideration
        """
        
        # Auto-upgrade category for CXO positions
        base_category_modifier = ""
        if contact.position_level == 'CXO':
            base_category_modifier = "\nNOTE: This is a CXO-level contact. Unless clearly irrelevant, lean toward Category C."
        
        crm_context = ""
        if self.crm_history:
            contact_key = f"{contact.name}_{contact.previous_company}".lower().replace(" ", "_")
            if contact_key in self.crm_history:
                crm_context = f"\nCRM History: {json.dumps(self.crm_history[contact_key], indent=2)}"
        
        prompt = f"""Categorize this ex-employee into one of four categories:

A – We directly dealt with them earlier at {contact.previous_company}
B – They were indirectly involved when we worked with {contact.previous_company}
C – We had no connection, but they are relevant for our services
D – Not relevant (wrong role, company, or industry)

Contact Information:
- Name: {contact.name}
- Previous Company: {contact.previous_company}
- Current Company: {contact.current_company}
- Current Title: {contact.current_title}
- Position Level: {contact.position_level}
- LinkedIn: {contact.linkedin_url}

Our Company Context:
{company_context}
{crm_context}
{base_category_modifier}

Return ONLY: A, B, C, or D"""

        message = self.claude.messages.create(
            model=self.model,
            max_tokens=100,
            messages=[{"role": "user", "content": prompt}]
        )
        
        category = message.content[0].text.strip().upper()
        return category if category in ['A', 'B', 'C', 'D'] else 'C'
    
    def create_profile(self, contact: Contact, web_research: str = "") -> Dict[str, str]:
        """Create profile (enhanced with position level)"""
        
        prompt = f"""Create a profile and approach plan for this ex-employee contact.

Contact Information:
- Name: {contact.name}
- Previous Company: {contact.previous_company}
- Current Company: {contact.current_company}
- Current Title: {contact.current_title}
- Position Level: {contact.position_level}
- Category: {contact.category}

Search Snippet:
{contact.search_snippet}

Additional Research:
{web_research if web_research else "No additional research"}

Provide:

1. PROFILE SUMMARY (2-3 sentences):
Background, current role, likely interests/pain points.

2. APPROACH PLAN (3-4 bullet points):
Best strategy to engage based on their career progression from {contact.previous_company} to current role.

Format as:
PROFILE:
[summary]

APPROACH:
[plan]"""

        message = self.claude.messages.create(
            model=self.model,
            max_tokens=500,
            messages=[{"role": "user", "content": prompt}]
        )
        
        response_text = message.content[0].text.strip()
        parts = response_text.split("APPROACH:")
        
        return {
            "profile_summary": parts[0].replace("PROFILE:", "").strip(),
            "approach_plan": parts[1].strip() if len(parts) > 1 else ""
        }
    
    def generate_custom_email(
        self, 
        contact: Contact, 
        our_services: str,
        campaign_goal: str = "schedule discovery call"
    ) -> str:
        """Generate custom email (enhanced with ex-employee angle)"""
        
        prompt = f"""Write a personalized B2B email for this ex-employee.

CONTACT:
- Name: {contact.name}
- Previous: {contact.current_title} at {contact.previous_company}
- Current: {contact.current_title} at {contact.current_company}
- Position Level: {contact.position_level}
- Category: {contact.category}

PROFILE:
{contact.profile_summary}

APPROACH:
{contact.approach_plan}

OUR SERVICES:
{our_services}

GOAL: {campaign_goal}

REQUIREMENTS:
1. Reference their move from {contact.previous_company} naturally
2. Position level appropriate tone ({contact.position_level})
3. 150-200 words max
4. Focus on value and outcomes
5. Clear call-to-action
6. For Category A/B: Reference our past work together
7. For CXO: Extra professional, strategic focus

Format:
SUBJECT: [subject]

[email]"""

        message = self.claude.messages.create(
            model=self.model,
            max_tokens=800,
            messages=[{"role": "user", "content": prompt}]
        )
        
        return message.content[0].text.strip()
    
    def process_ex_employees(
        self,
        company_name: str,
        company_context: str,
        our_services: str,
        max_results: int = 100,
        campaign_goal: str = "schedule discovery call",
        output_file: str = "ex_employees_processed.json"
    ) -> Tuple[List[Contact], Dict]:
        """
        Complete pipeline: Search → Categorize → Profile → Email
        
        Args:
            company_name: Company to find ex-employees from
            company_context: Context about our company
            our_services: Our service offerings
            max_results: Max contacts to find
            campaign_goal: Campaign objective
            output_file: Output filename
            
        Returns:
            Tuple of (processed_contacts, statistics)
        """
        
        # Step 1: Find ex-employees
        contacts, stats = self.find_ex_employees(company_name, max_results)
        
        if not contacts:
            return [], stats
        
        # Step 2: Process each contact
        print(f"\n{'='*70}")
        print(f"PROCESSING {len(contacts)} CONTACTS")
        print(f"{'='*70}\n")
        
        processed_contacts = []
        
        for i, contact in enumerate(contacts, 1):
            print(f"[{i}/{len(contacts)}] {contact.name} ({contact.position_level})")
            
            try:
                # Categorize
                contact.category = self.categorize_contact(contact, company_context)
                print(f"  ✓ Category: {contact.category}")
                
                # Skip Category D
                if contact.category == 'D':
                    print(f"  ✗ Skipping Category D")
                    processed_contacts.append(contact)
                    continue
                
                # Profile
                profile_data = self.create_profile(contact)
                contact.profile_summary = profile_data['profile_summary']
                contact.approach_plan = profile_data['approach_plan']
                print(f"  ✓ Profile created")
                
                # Email
                contact.custom_email = self.generate_custom_email(
                    contact, our_services, campaign_goal
                )
                print(f"  ✓ Email generated")
                
                processed_contacts.append(contact)
                
                # Save progress every 10 contacts
                if i % 10 == 0:
                    self._save_results(processed_contacts, output_file)
                
                # Rate limiting
                time.sleep(0.5)
                
            except Exception as e:
                print(f"  ✗ Error: {e}")
                contact.category = "ERROR"
                processed_contacts.append(contact)
        
        # Final save
        self._save_results(processed_contacts, output_file)
        
        # Final summary
        final_stats = self._generate_final_stats(processed_contacts, stats)
        self._print_final_summary(final_stats, company_name)
        
        return processed_contacts, final_stats
    
    def _save_results(self, contacts: List[Contact], filename: str):
        """Save results to JSON"""
        with open(filename, 'w') as f:
            json.dump([c.to_dict() for c in contacts], f, indent=2)
    
    def _generate_final_stats(self, contacts: List[Contact], search_stats: Dict) -> Dict:
        """Generate final processing statistics"""
        
        stats = search_stats.copy()
        stats['categories'] = {'A': 0, 'B': 0, 'C': 0, 'D': 0, 'ERROR': 0}
        stats['emails_generated'] = 0
        
        for contact in contacts:
            cat = contact.category or 'ERROR'
            stats['categories'][cat] = stats['categories'].get(cat, 0) + 1
            
            if contact.custom_email:
                stats['emails_generated'] += 1
        
        return stats
    
    def _print_final_summary(self, stats: Dict, company_name: str):
        """Print final processing summary"""
        
        print(f"\n{'='*70}")
        print(f"FINAL SUMMARY: {company_name} Ex-Employees")
        print(f"{'='*70}")
        print(f"Total Found: {stats['total']}")
        print(f"\nPosition Levels:")
        print(f"  🔴 CXO:     {stats['by_level']['CXO']}")
        print(f"  🟠 Senior:  {stats['by_level']['SENIOR']}")
        print(f"  🟡 Manager: {stats['by_level']['MANAGER']}")
        print(f"  ⚪ Other:   {stats['by_level']['OTHER']}")
        print(f"\nCategories:")
        print(f"  A (Direct):      {stats['categories']['A']}")
        print(f"  B (Indirect):    {stats['categories']['B']}")
        print(f"  C (Relevant):    {stats['categories']['C']}")
        print(f"  D (Not Relevant): {stats['categories']['D']}")
        print(f"\n📧 Emails Generated: {stats['emails_generated']}")
        print(f"⭐ High Value Contacts: {stats['high_value']}")
        print(f"{'='*70}\n")


# Example usage
if __name__ == "__main__":
    
    # Initialize
    ANTHROPIC_KEY = os.getenv("ANTHROPIC_API_KEY")
    SEARCHAPI_KEY = os.getenv("SEARCHAPI_KEY")  # Your SearchAPI key
    
    if not ANTHROPIC_KEY or not SEARCHAPI_KEY:
        print("Error: Set ANTHROPIC_API_KEY and SEARCHAPI_KEY environment variables")
        exit(1)
    
    agent = EnhancedSalesAgent(
        anthropic_api_key=ANTHROPIC_KEY,
        searchapi_key=SEARCHAPI_KEY
    )
    
    # Company context
    COMPANY_CONTEXT = """
    We are DPA (Decimal Point Analytics), a digital transformation consultancy.
    We specialize in AI/ML, cloud migration, data analytics, and process automation.
    We've worked with major financial services and healthcare companies.
    """
    
    OUR_SERVICES = """
    - AI & ML Solutions
    - Data Platform Modernization
    - Intelligent Automation
    - Analytics & Business Intelligence
    """
    
    # Find and process ex-employees
    contacts, stats = agent.process_ex_employees(
        company_name="Decimal Point Analytics",
        company_context=COMPANY_CONTEXT,
        our_services=OUR_SERVICES,
        max_results=50,
        output_file="dpa_ex_employees.json"
    )
    
    # Show top CXO contacts
    print("\n🔴 TOP CXO CONTACTS:")
    print("="*70)
    cxo_contacts = [c for c in contacts if c.position_level == 'CXO' and c.category in ['A', 'B', 'C']]
    for c in cxo_contacts[:5]:
        print(f"{c.name}")
        print(f"  {c.current_title} at {c.current_company}")
        print(f"  Category: {c.category}")
        print()
