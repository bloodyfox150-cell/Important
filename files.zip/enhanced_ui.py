"""
Enhanced Streamlit UI with LinkedIn Search Integration
Run with: streamlit run enhanced_ui.py
"""

import streamlit as st
import pandas as pd
import json
from enhanced_sales_agent import EnhancedSalesAgent, Contact, PositionAnalyzer
import os
from datetime import datetime

# Page config
st.set_page_config(
    page_title="Ex-Employee Outreach Agent",
    page_icon="🔍",
    layout="wide"
)

# Custom CSS
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        color: #FF6B35;
        font-weight: bold;
    }
    .position-cxo { 
        background-color: #FF4444; 
        color: white; 
        padding: 0.25rem 0.5rem; 
        border-radius: 0.25rem;
        font-weight: bold;
    }
    .position-senior { 
        background-color: #FF8C00; 
        color: white; 
        padding: 0.25rem 0.5rem; 
        border-radius: 0.25rem;
        font-weight: bold;
    }
    .position-manager { 
        background-color: #FFD700; 
        color: black; 
        padding: 0.25rem 0.5rem; 
        border-radius: 0.25rem;
        font-weight: bold;
    }
    .position-other { 
        background-color: #CCCCCC; 
        color: black; 
        padding: 0.25rem 0.5rem; 
        border-radius: 0.25rem;
    }
</style>
""", unsafe_allow_html=True)

# Initialize session state
if 'agent' not in st.session_state:
    st.session_state.agent = None
if 'contacts' not in st.session_state:
    st.session_state.contacts = []
if 'stats' not in st.session_state:
    st.session_state.stats = {}

# Header
st.markdown('<div class="main-header">🔍 Ex-Employee LinkedIn Outreach Agent</div>', unsafe_allow_html=True)
st.markdown("Find and engage former employees who moved to senior positions")

# Sidebar
with st.sidebar:
    st.header("⚙️ Configuration")
    
    # API Keys
    st.subheader("API Keys")
    anthropic_key = st.text_input("Anthropic API Key", type="password")
    searchapi_key = st.text_input("SearchAPI Key", type="password")
    
    # Initialize
    if st.button("🚀 Initialize Agent", type="primary", use_container_width=True):
        if not anthropic_key or not searchapi_key:
            st.error("Please enter both API keys")
        else:
            try:
                st.session_state.agent = EnhancedSalesAgent(
                    anthropic_api_key=anthropic_key,
                    searchapi_key=searchapi_key
                )
                st.success("✅ Agent initialized!")
            except Exception as e:
                st.error(f"Error: {e}")
    
    st.divider()
    
    # Info
    st.info("""
    **How it works:**
    1. Search LinkedIn for ex-employees
    2. Prioritize by position (CXO > Senior)
    3. Categorize and create profiles
    4. Generate personalized emails
    """)

# Main content
if not st.session_state.agent:
    st.warning("👈 Initialize the agent in the sidebar to get started")
    
    st.subheader("Position Classification")
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("**🔴 CXO Level**")
        st.write("CEO, CTO, CFO, COO, President, Founder, Managing Director")
        
        st.markdown("**🟠 Senior Level**")
        st.write("VP, SVP, Director, Head of, Partner, Principal")
    
    with col2:
        st.markdown("**🟡 Manager Level**")
        st.write("Manager, Team Lead, Project Manager, Program Manager")
        
        st.markdown("**⚪ Other**")
        st.write("All other positions")

else:
    tabs = st.tabs(["🔍 Search", "⚙️ Configure", "📊 Results"])
    
    # TAB 1: SEARCH
    with tabs[0]:
        st.header("Search for Ex-Employees")
        
        col1, col2 = st.columns([2, 1])
        
        with col1:
            company_name = st.text_input(
                "Company Name",
                placeholder="e.g., Decimal Point Analytics",
                help="Search for former employees of this company"
            )
        
        with col2:
            max_results = st.number_input(
                "Max Results",
                min_value=10,
                max_value=100,
                value=50,
                help="Maximum number of LinkedIn profiles to find"
            )
        
        if st.button("🔍 Search LinkedIn", type="primary", use_container_width=True):
            if not company_name:
                st.error("Please enter a company name")
            else:
                with st.spinner(f"Searching for ex-employees of {company_name}..."):
                    contacts, stats = st.session_state.agent.find_ex_employees(
                        company_name=company_name,
                        max_results=max_results
                    )
                    
                    st.session_state.contacts = contacts
                    st.session_state.stats = stats
                    st.session_state.company_name = company_name
                
                if contacts:
                    st.success(f"✅ Found {len(contacts)} ex-employees!")
                    
                    # Show summary
                    col1, col2, col3, col4 = st.columns(4)
                    
                    with col1:
                        st.metric("🔴 CXO", stats['by_level']['CXO'])
                    with col2:
                        st.metric("🟠 Senior", stats['by_level']['SENIOR'])
                    with col3:
                        st.metric("🟡 Manager", stats['by_level']['MANAGER'])
                    with col4:
                        st.metric("⭐ High Value", stats['high_value'])
                    
                    # Preview top contacts
                    st.subheader("Top Contacts Preview")
                    
                    preview_df = pd.DataFrame([
                        {
                            'Name': c.name,
                            'Position Level': c.position_level,
                            'Current Title': c.current_title,
                            'Current Company': c.current_company,
                            'LinkedIn': c.linkedin_url
                        }
                        for c in contacts[:10]
                    ])
                    
                    st.dataframe(preview_df, use_container_width=True)
                else:
                    st.warning("No ex-employees found. Try a different company name.")
    
    # TAB 2: CONFIGURE
    with tabs[1]:
        st.header("Campaign Configuration")
        
        if not st.session_state.contacts:
            st.info("Search for ex-employees first in the Search tab")
        else:
            col1, col2 = st.columns(2)
            
            with col1:
                st.subheader("Company Context")
                company_context = st.text_area(
                    "About Your Company",
                    height=200,
                    value="""We are DPA (Decimal Point Analytics), a digital transformation consultancy.
We specialize in:
- AI/ML implementation
- Cloud migration
- Data analytics
- Process automation

We've worked with Fortune 500 companies in financial services and healthcare.""",
                    help="Context about your company for better categorization"
                )
            
            with col2:
                st.subheader("Services")
                our_services = st.text_area(
                    "Your Services",
                    height=200,
                    value="""Our key offerings:
1. AI & Machine Learning Solutions
2. Data Platform Modernization
3. Intelligent Automation
4. Analytics & Business Intelligence
5. Cloud Migration & Modernization""",
                    help="Services to mention in emails"
                )
            
            campaign_goal = st.text_input(
                "Campaign Goal",
                value="schedule 30-minute discovery call",
                help="What action do you want them to take?"
            )
            
            # Process button
            st.divider()
            
            col1, col2, col3 = st.columns([1, 2, 1])
            with col2:
                if st.button(
                    f"🚀 Process {len(st.session_state.contacts)} Contacts",
                    type="primary",
                    use_container_width=True
                ):
                    progress_bar = st.progress(0)
                    status = st.empty()
                    
                    # Save config
                    st.session_state.company_context = company_context
                    st.session_state.our_services = our_services
                    st.session_state.campaign_goal = campaign_goal
                    
                    # Process
                    processed = []
                    total = len(st.session_state.contacts)
                    
                    for i, contact in enumerate(st.session_state.contacts):
                        status.text(f"Processing {i+1}/{total}: {contact.name}")
                        
                        try:
                            # Categorize
                            contact.category = st.session_state.agent.categorize_contact(
                                contact, company_context
                            )
                            
                            # Skip D
                            if contact.category == 'D':
                                processed.append(contact)
                                progress_bar.progress((i + 1) / total)
                                continue
                            
                            # Profile
                            profile_data = st.session_state.agent.create_profile(contact)
                            contact.profile_summary = profile_data['profile_summary']
                            contact.approach_plan = profile_data['approach_plan']
                            
                            # Email
                            contact.custom_email = st.session_state.agent.generate_custom_email(
                                contact, our_services, campaign_goal
                            )
                            
                            processed.append(contact)
                            
                        except Exception as e:
                            st.error(f"Error processing {contact.name}: {e}")
                            contact.category = "ERROR"
                            processed.append(contact)
                        
                        progress_bar.progress((i + 1) / total)
                    
                    st.session_state.contacts = processed
                    status.text("✅ Processing complete!")
                    st.success(f"Processed {len(processed)} contacts!")
                    
                    # Switch to results
                    st.rerun()
    
    # TAB 3: RESULTS
    with tabs[2]:
        st.header("Results & Insights")
        
        if not st.session_state.contacts:
            st.info("No contacts to display. Search and process contacts first.")
        elif not any(c.category for c in st.session_state.contacts):
            st.warning("Contacts found but not processed. Go to Configure tab to process them.")
        else:
            contacts = st.session_state.contacts
            
            # Summary metrics
            st.subheader("📊 Summary")
            
            col1, col2, col3, col4, col5 = st.columns(5)
            
            categories = {'A': 0, 'B': 0, 'C': 0, 'D': 0}
            for c in contacts:
                cat = c.category or 'D'
                categories[cat] = categories.get(cat, 0) + 1
            
            with col1:
                st.metric("Total", len(contacts))
            with col2:
                st.metric("Category A", categories['A'])
            with col3:
                st.metric("Category B", categories['B'])
            with col4:
                st.metric("Category C", categories['C'])
            with col5:
                emails = categories['A'] + categories['B'] + categories['C']
                st.metric("Emails Ready", emails)
            
            # Filters
            st.divider()
            st.subheader("🔍 Filter & View")
            
            col1, col2 = st.columns(2)
            
            with col1:
                filter_level = st.multiselect(
                    "Position Level",
                    ['CXO', 'SENIOR', 'MANAGER', 'OTHER'],
                    default=['CXO', 'SENIOR']
                )
            
            with col2:
                filter_category = st.multiselect(
                    "Category",
                    ['A', 'B', 'C', 'D'],
                    default=['A', 'B', 'C']
                )
            
            # Filter contacts
            filtered = [
                c for c in contacts 
                if c.position_level in filter_level 
                and c.category in filter_category
            ]
            
            st.info(f"Showing {len(filtered)} of {len(contacts)} contacts")
            
            # Display contacts
            for contact in filtered:
                # Position badge
                level_class = f"position-{contact.position_level.lower()}"
                
                with st.expander(
                    f"**{contact.name}** - {contact.current_company} "
                    f"| {contact.position_level} | Cat: {contact.category}"
                ):
                    col1, col2 = st.columns([1, 1])
                    
                    with col1:
                        st.markdown("**Contact Details**")
                        st.write(f"**Name:** {contact.name}")
                        st.write(f"**Previous:** {contact.previous_company}")
                        st.write(f"**Current Title:** {contact.current_title}")
                        st.write(f"**Current Company:** {contact.current_company}")
                        
                        st.markdown(
                            f'**Position Level:** <span class="{level_class}">{contact.position_level}</span>',
                            unsafe_allow_html=True
                        )
                        
                        st.write(f"**Category:** {contact.category}")
                        st.write(f"**LinkedIn:** {contact.linkedin_url}")
                    
                    with col2:
                        if contact.profile_summary:
                            st.markdown("**Profile Summary**")
                            st.write(contact.profile_summary)
                            
                            st.markdown("**Approach Plan**")
                            st.write(contact.approach_plan)
                    
                    if contact.custom_email:
                        st.markdown("**Generated Email**")
                        st.code(contact.custom_email, language=None)
            
            # Export
            st.divider()
            st.subheader("📥 Export")
            
            col1, col2 = st.columns(2)
            
            with col1:
                # JSON export
                json_data = json.dumps([c.to_dict() for c in filtered], indent=2)
                st.download_button(
                    "📄 Download JSON",
                    data=json_data,
                    file_name=f"ex_employees_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
                    mime="application/json",
                    use_container_width=True
                )
            
            with col2:
                # CSV export
                df = pd.DataFrame([c.to_dict() for c in filtered])
                csv_data = df.to_csv(index=False)
                st.download_button(
                    "📊 Download CSV",
                    data=csv_data,
                    file_name=f"ex_employees_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                    mime="text/csv",
                    use_container_width=True
                )

# Footer
st.divider()
st.caption("Ex-Employee LinkedIn Outreach Agent | Powered by Claude & SearchAPI")
